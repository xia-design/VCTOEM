class cluster:
    @classmethod
    def cluster_ac_choose(cls, num_t, action, task_list=None, cluster=None):

        #初始化默认值，避免空列表问题
        if task_list is None:
            task_list = []
        if cluster is None:
            cluster = []
        offloading_decision = []
        if num_t == 0 or not task_list or not cluster:  # 无任务/无簇，直接返回空
            return offloading_decision

        #获取实际簇数量（动态，可能少于5）
        actual_cluster_num = len(cluster)
        if actual_cluster_num == 0:
            return offloading_decision

        #动作区间归一化：将动作（0~1）映射到实际簇数量对应的区间
        segment_num = actual_cluster_num
        segment_width = 1.0 / segment_num  # 每个簇对应的动作区间宽度

        # 单任务分配（num_t=1）
        if num_t == 1:
            # 按动作区间选择簇（动态适配实际簇数量）
            selected_cluster_idx = min(int(action // segment_width), actual_cluster_num - 1)
            # 安全获取选中的簇（避免簇为空）
            selected_cluster = cluster[selected_cluster_idx] if cluster[selected_cluster_idx] else cluster[0]
            # 任务-簇分配（取第一个任务）
            p = [task_list[0], selected_cluster]
            offloading_decision.append(p)
            return offloading_decision

        # 多任务分配（num_t=2~5）：按任务数动态生成动作区间
        # 核心逻辑：将动作（0~1）分为 (实际簇数量^num_t) 个区间，确保覆盖所有可能分配组合
        max_combinations = actual_cluster_num ** num_t  # 最大分配组合数
        if max_combinations == 0:
            return offloading_decision
        combination_idx = min(int(action * max_combinations), max_combinations - 1)  # 动作映射到组合索引

        # 生成任务-簇分配组合
        task_cluster_idx = []  # 存储每个任务对应的簇索引
        for _ in range(num_t):
            # 按进制转换逻辑，从组合索引中解析每个任务的簇索引
            task_cluster_idx.append(combination_idx % actual_cluster_num)
            combination_idx = combination_idx // actual_cluster_num
        task_cluster_idx.reverse()  # 反转后匹配任务顺序（任务0对应第一个解析的簇）

        # 执行任务-簇分配（安全检查簇有效性）
        for task_idx in range(num_t):
            if task_idx >= len(task_list):  # 任务列表长度不足，终止分配
                break
            # 解析当前任务的簇索引（兼容簇数量不足）
            c_idx = task_cluster_idx[task_idx] if task_cluster_idx else 0
            c_idx = min(c_idx, actual_cluster_num - 1)  # 确保不超出实际簇数量
            # 安全获取簇（若当前簇为空，使用第一个有效簇）
            target_cluster = cluster[c_idx] if cluster[c_idx] else cluster[0]
            # 添加分配结果
            p = [task_list[task_idx], target_cluster]
            offloading_decision.append(p)

        return offloading_decision

