import copy
import math
import matplotlib.pyplot as plt
import numpy as np

np.random.seed(1024)
# import xiaVehicle
# from xiaVehicle import *
import V_information
from V_information import *

from task1 import *
from gym.utils import seeding
from cluster_3 import cluster


def flatten(a):  # 将多维无规则列表降到一维
    for each in a:
        if not isinstance(each, list):
            yield each
        else:
            yield from flatten(each)


class Roadenvironment(object):
    def __init__(self):


        self.A = 2  # 无人机数2

        self.B = 8  # Rsu数8

        # 初始化RSU任务计数：每个RSU初始任务数为0
        self.rsu_task_count = [0] * self.B  # 长度为RSU数量，初始值为0

        self.rsu_loaded = [0.0] * self.B  # 存储每个RSU的负载率（0~1）

        self.task_vehicle = 5  # 产生任务车辆数量5

        self.task_information = [[] for _ in range(self.task_vehicle)]  # 核心替换对象

        self.D = 200  # 愿意处理任务车辆数量200
        self.T = 10  # 周期间隔10s交互

        self.transmit_power = 0.1  # 任务发射功率



        self.r_uav = 300  # 无人机覆盖范围 确保其存在交叠区域
        self.r_rsu = 125  # RSU覆盖范围

        self.road_length = 1000  # 公路长度1000m
        self.road_width_left = 12  # 左车道 12 m
        self.road_width_right = 12  # 右车道 12 m
        self.road_width=24
        # 十字路口参数：
        self.road_length = 1000
        self.road_length_x = 1000  # X方向公路长度（横向）
        self.road_length_y = 1000  # Y方向公路长度（纵向）
        self.road_width_x = 24  # X方向公路总宽度（原左+右车道）
        self.road_width_y = 24  # Y方向公路总宽度
        self.intersection = [500, 500]  # 十字路口中心坐标（两条路的交点）

        self.Rsu_cc = 2e9  # RSU计算速率 3G cycles/s  2
        self.uav_cc = 8e9  # 无人机计算速率 7G cycles/s  8
        self.s = 0.1
        self.noise_power = 1e-10  # 噪声功率 1e-10 W
        # 定义三种链路的带宽参数 (单位: Hz)
        self.bandwidth_v2u = 12e6  # 12 MHz - V2U带宽
        self.bandwidth_v2v = 10e6  # 10 MHz - V2V带宽
        self.bandwidth_v2i = 8e6  # 8 MHz  - V2I带宽

        # 定义三种链路的信道增益
        self.channel_gain_v2u = 1.2e-7  # V2U信道增益
        self.channel_gain_v2v = 1.0e-7  # V2V信道增益
        self.channel_gain_v2i = 0.8e-7  # V2I信道增益

        # 计算传输速率
        self.tran_v2u = self._calculate_shannon_rate(
            self.transmit_power, self.channel_gain_v2u, self.bandwidth_v2u)
        self.tran_v2v = self._calculate_shannon_rate(
            self.transmit_power, self.channel_gain_v2v, self.bandwidth_v2v)
        self.tran_V2I = self._calculate_shannon_rate(
            self.transmit_power, self.channel_gain_v2i, self.bandwidth_v2i)


        self.Rsu_location = [
            # X方向公路的RSU（横向）
            [125, 500], [375, 500], [625, 500], [875, 500],
            # Y方向公路的RSU（纵向，新增）
            [500, 125], [500, 375], [500, 625], [500, 875]
        ]  # 共8个RSU，覆盖两条公路覆盖两条公路

        # 新增2个无人机作为卸载节点（替代基站和旧无人机）
        self.uav_num = 2  # 新无人机数量（固定2个）
        self.uav_config = {
            0: {
                "init_pos": [300, 500],  # 初始位置（X方向公路）
                "cruise_center": [300, 500],  # 基础巡航中心
                "radius": 150,  # 基础巡航半径（m）
                "speed": 8,  # 巡航速度（m/s）
                "coverage": 300,  # 通信覆盖半径（m）
                "compute_cap": 8e9,  # 计算能力（cycles/s）
                "current_angle": 0.0  # 巡航角度（用于轨迹计算）
            },
            1: {
                "init_pos": [700, 500],  # 初始位置（X方向公路）
                "cruise_center": [700, 500],  # 基础巡航中心
                "radius": 150,  # 基础巡航半径（m）
                "speed": 8,  # 巡航速度（m/s）
                "coverage": 300,  # 通信覆盖半径（m）
                "compute_cap": 8e9,  # 计算能力（cycles/s）
                "current_angle": 0.0  # 巡航角度（用于轨迹计算）
            }
        }
        self.uav_current_pos = {  # 无人机实时位置（初始化）
            0: self.uav_config[0]["init_pos"].copy(),
            1: self.uav_config[1]["init_pos"].copy()
        }


        self.b_cost = 3e-9
        self.r_cost = 1e-9
        self.v_cost = 2e-11
        self.aw_b = 1e-6  # 无人机奖励值
        self.aw_r = 5e-6  # RSU奖励值
        # self.aw_v = 5e-7  # 车辆簇奖励值
        self.aw_ch = 5e-5  # 簇头奖励
        self.ve = information.ve_information()  # 协助车辆 位置、速度、方向、算力、可用资源、通信半径
        self.ve.tolist()
        self.cb = information.ve_cm(self=True)
        self.tve = information.ve_t_information(self=True)  # 任务车辆
        # *******获取5辆任务车辆生成w+2个任务所有子任务信息********
        self.v0 = task.task_generate()
        self.v1 = task.task_generate()
        self.v2 = task.task_generate()
        self.v3 = task.task_generate()
        self.v4 = task.task_generate()
        self.t_list = [self.v0, self.v1, self.v2, self.v3, self.v4]
        # *******获取5辆任务车辆生成任务总信息********
        self.v0_a = task.get_total_task_information(self.v0)
        self.v1_a = task.get_total_task_information(self.v1)
        self.v2_a = task.get_total_task_information(self.v2)
        self.v3_a = task.get_total_task_information(self.v3)
        self.v4_a = task.get_total_task_information(self.v4)
        self.v_list = [self.v0_a, self.v1_a, self.v2_a, self.v3_a, self.v4_a]
        t0 = self.local_latency_in(0, self.v0) + self.local_latency_out(0, self.v0)
        t1 = self.local_latency_in(1, self.v1) + self.local_latency_out(1, self.v1)
        t2 = self.local_latency_in(2, self.v2) + self.local_latency_out(2, self.v2)
        t3 = self.local_latency_in(3, self.v3) + self.local_latency_out(3, self.v3)
        t4 = self.local_latency_in(4, self.v4) + self.local_latency_out(4, self.v4)
        self.io_time = [t0, t1, t2, t3, t4]
        e0 = self.local_energy_in(0, self.v0) + self.local_energy_out(0, self.v0)
        e1 = self.local_energy_in(1, self.v1) + self.local_energy_out(1, self.v1)
        e2 = self.local_energy_in(2, self.v2) + self.local_energy_out(2, self.v2)
        e3 = self.local_energy_in(3, self.v3) + self.local_energy_out(3, self.v3)
        e4 = self.local_energy_in(4, self.v4) + self.local_energy_out(4, self.v4)
        self.io_energy = [e0, e1, e2, e3, e4]

    def _calculate_shannon_rate(self, power, channel_gain, bandwidth):
        """香农公式计算速率"""
        snr = (power * channel_gain) / self.noise_power
        if snr > 1e10:
            snr = 1e10
        return bandwidth * math.log2(1 + snr)

    def reset(self):
        self.cb = information.ve_cm(self=True)

        # 无人机状态初始化
        for uav_id in range(self.uav_num):
            # 重置位置为初始位置
            self.uav_current_pos[uav_id] = self.uav_config[uav_id]["init_pos"].copy()
            # 重置巡航参数
            self.uav_config[uav_id]["current_angle"] = 0.0  # 角度归零
            self.uav_config[uav_id]["cruise_center"] = self.uav_config[uav_id]["init_pos"].copy()  # 重置巡航中心
            self.uav_config[uav_id]["radius"] = 150  # 重置巡航半径
        self.uav_loaded = np.zeros(self.uav_num)  # 无人机负载状态
        self.uav_task_count = np.zeros(self.uav_num, dtype=int)  # 无人机任务计数

        #     self.tve = information.ve_t_information(self=True)  # 任务车辆
        # *******获取5辆任务车辆生成w+2个任务所有子任务信息********
        self.v0 = task.task_generate()
        self.v1 = task.task_generate()
        self.v2 = task.task_generate()
        self.v3 = task.task_generate()
        self.v4 = task.task_generate()
        self.t_list = [self.v0, self.v1, self.v2, self.v3, self.v4]
        # *******获取5辆任务车辆生成任务总信息********
        self.v0_a = task.get_total_task_information(self.v0)
        self.v1_a = task.get_total_task_information(self.v1)
        self.v2_a = task.get_total_task_information(self.v2)
        self.v3_a = task.get_total_task_information(self.v3)
        self.v4_a = task.get_total_task_information(self.v4)
        self.v_list = [self.v0_a, self.v1_a, self.v2_a, self.v3_a, self.v4_a]
        t0 = self.local_latency_in(0, self.v0) + self.local_latency_out(0, self.v0)
        t1 = self.local_latency_in(1, self.v1) + self.local_latency_out(1, self.v1)
        t2 = self.local_latency_in(2, self.v2) + self.local_latency_out(2, self.v2)
        t3 = self.local_latency_in(3, self.v3) + self.local_latency_out(3, self.v3)
        t4 = self.local_latency_in(4, self.v4) + self.local_latency_out(4, self.v4)
        self.io_time = [t0, t1, t2, t3, t4]

        e0 = self.local_energy_in(0, self.v0) + self.local_energy_out(0, self.v0)
        e1 = self.local_energy_in(1, self.v1) + self.local_energy_out(1, self.v1)
        e2 = self.local_energy_in(2, self.v2) + self.local_energy_out(2, self.v2)
        e3 = self.local_energy_in(3, self.v3) + self.local_energy_out(3, self.v3)
        e4 = self.local_energy_in(4, self.v4) + self.local_energy_out(4, self.v4)
        self.io_energy = [e0, e1, e2, e3, e4]



    def update_task_status(self):
        """更新任务状态：移除已完成任务，同步RSU和无人机任务计数"""
        for ve_id in range(self.task_vehicle):
            if not self.task_information[ve_id]:
                continue  # 无任务跳过

            # 检查任务是否完成
            task = self.task_information[ve_id][0]
            task_type, task_params, task_deadline, executor_type, executor_id = task

            # 减少任务剩余时间
            task_remaining = task_params[-1] - self.T
            if task_remaining <= 0:
                # 任务完成：更新执行节点计数
                if executor_type == "rsu":
                    self.rsu_task_count[executor_id] -= 1
                elif executor_type == "uav":
                    self.uav_task_count[executor_id] -= 1
                # 移除任务
                self.task_information[ve_id].pop(0)

    def update_load_status(self):
        """更新负载状态：基于任务计数计算RSU和无人机负载"""
        # RSU负载计算
        for rsu_id in range(self.B):

            self.rsu_loaded[rsu_id] = min(self.rsu_task_count[rsu_id] / 10, 1.0)

        # 无人机负载计算
        for uav_id in range(self.uav_num):
            # 负载 = 任务数 / 最大任务容量
            self.uav_loaded[uav_id] = min(self.uav_task_count[uav_id] / 8, 1.0)

    def improved_pso_for_uav(self, uav_id, task_positions):
        """
        改进PSO算法
        """
        uav = self.uav_config[uav_id]
        # PSO参数设置（动态惯性权重+自适应学习因子）
        pop_size = 10  # 粒子数量
        max_iter = 15  # 最大迭代次数
        w_max, w_min = 0.9, 0.4  # 惯性权重范围
        c1, c2 = 2.0, 2.0  # 学习因子

        # 粒子初始化
        particles = []
        for _ in range(pop_size):
            x = np.random.uniform(
                max(0, uav["cruise_center"][0] - 200),
                min(self.road_length_x, uav["cruise_center"][0] + 200)
            )
            y = np.random.uniform(
                max(0, uav["cruise_center"][1] - 200),
                min(self.road_length_y, uav["cruise_center"][1] + 200)
            )
            r = np.random.uniform(100, 300)
            particles.append({"pos": [x, y, r], "vel": [0, 0, 0], "p_best": [x, y, r], "p_best_val": -np.inf})

        #  全局最优初始化
        g_best = particles[0]["pos"].copy()
        g_best_val = self._pso_fitness(g_best, task_positions)

        # PSO迭代
        for iter in range(max_iter):
            # 动态更新惯性权重
            w = w_max - (w_max - w_min) * (iter / max_iter)
            # 自适应学习因子
            if iter < max_iter / 2:
                c1, c2 = 2.5, 1.5
            else:
                c1, c2 = 1.5, 2.5

            for particle in particles:
                pos = particle["pos"]
                vel = particle["vel"]
                p_best = particle["p_best"]

                # 计算速度
                r1, r2 = np.random.rand(3), np.random.rand(3)
                new_vel = (
                        w * np.array(vel) +
                        c1 * r1 * (np.array(p_best) - np.array(pos)) +
                        c2 * r2 * (np.array(g_best) - np.array(pos))
                )
                # 速度约束
                new_vel = np.clip(new_vel, [-5, -5, -10], [5, 5, 10])
                particle["vel"] = new_vel.tolist()

                # 更新位置
                new_pos = np.array(pos) + new_vel
                # 位置约束
                new_pos[0] = np.clip(new_pos[0], 0, self.road_length_x)
                new_pos[1] = np.clip(new_pos[1], 0, self.road_length_y)
                new_pos[2] = np.clip(new_pos[2], 100, 300)
                particle["pos"] = new_pos.tolist()

                # 更新个体最优
                current_val = self._pso_fitness(new_pos, task_positions)
                if current_val > particle["p_best_val"]:
                    particle["p_best"] = new_pos.tolist()
                    particle["p_best_val"] = current_val

                # 更新全局最优
                if current_val > g_best_val:
                    g_best = new_pos.tolist()
                    g_best_val = current_val

        # 返回最优参数
        opt_center = [g_best[0], g_best[1]]
        opt_radius = g_best[2]
        return opt_center, opt_radius

    def _pso_fitness(self, particle_pos, task_positions):
        """
        PSO适应度函数：评估粒子（巡航参数）的优劣
        """
        center_x, center_y, radius = particle_pos
        covered_count = 0  # 覆盖的任务数
        avg_dist = 0  # 覆盖任务到中心的平均距离

        for (tx, ty) in task_positions:
            dist = np.sqrt((tx - center_x) ** 2 + (ty - center_y) ** 2)
            if dist <= radius:
                covered_count += 1
                avg_dist += dist

        # 适应度计算：覆盖数权重0.7 + 平均距离倒数权重0.3
        if covered_count == 0:
            return 0.0
        avg_dist = avg_dist / covered_count
        fitness = 0.7 * covered_count - 0.3 * (avg_dist / 100)  # 归一化距离影响
        return fitness

    def optimize_uav_trajectory(self):
        """2个无人机轨迹优化：基于改进PSO算法动态调整巡航参数"""
        #  收集当前所有任务车辆位置（用于PSO优化依据）
        task_positions = [
            (self.tve[i][0], self.tve[i][1])
            for i in range(self.task_vehicle)
        ]

        for uav_id in range(self.uav_num):  # 仅遍历2个无人机
            uav = self.uav_config[uav_id]
            current_pos = self.uav_current_pos[uav_id]

            opt_cruise_center, opt_cruise_radius = self.improved_pso_for_uav(uav_id, task_positions)
            # 更新无人机巡航参数
            uav["cruise_center"] = opt_cruise_center
            uav["radius"] = opt_cruise_radius

            angle_increment = (uav["speed"] * self.T) / uav["radius"]  # 角度增量（弧度）
            uav["current_angle"] += angle_increment
            # 计算新位置（
            cruise_center = uav["cruise_center"]
            new_x = cruise_center[0] + uav["radius"] * math.cos(uav["current_angle"])
            new_y = cruise_center[1] + uav["radius"] * math.sin(uav["current_angle"])
            # 边界约束
            new_x = max(0, min(new_x, self.road_length_x))
            new_y = max(0, min(new_y, self.road_length_y))
            self.uav_current_pos[uav_id] = [new_x, new_y]


    def distance(self, x, y):  # 只计算空闲车辆车与车距离
        temp = self.ve
        dis = np.sqrt(abs(temp[x][0] - temp[y][0]) ** 2 + abs(temp[x][1] - temp[y][1]) ** 2)
        return dis

    def connect_time(self, x):  # 计算接连时间
        t_list = []
        m_list = []
        m_list = self.neighbor(x)

        r = self.ve[x][2]
        v1 = self.ve[x][3]
        for i in range(len(m_list)):
            t1 = m_list[i]
            b = abs(self.ve[x][1] - self.ve[int(t1)][1])  # 纵坐标差
            a = abs(self.ve[x][0] - self.ve[int(t1)][0])  # 横坐标差
            f = self.ve[x][0] - self.ve[int(t1)][0]  # 通过横坐标差判断位置
            e = math.asin(b / r)
            v2 = self.ve[int(t1)][3]

            if (((v1 > 0 and v2 > 0) and f < 0) or ((v1 < 0 and v2 < 0) and f > 0) or (
                    (v1 < 0 and v2 > 0) and f < 0) or (
                    (v1 > 0 and v2 < 0) and f > 0)):  # 短边
                d = abs(r * math.cos(e))
                h = d - a
                ti = h / abs(v1 - v2)
                if (v2 > 0):
                    tx = (self.road_length - self.ve[int(t1)][0]) / v2
                else:
                    tx = self.ve[int(t1)][0] / abs(v2)
                if (tx > ti):
                    t_list.append(ti)
                else:
                    t_list.append(tx)
            elif (((v1 > 0 and v2 > 0) and f > 0) or ((v1 < 0 and v2 < 0) and f < 0) or (
                    (v1 < 0 and v2 > 0) and f > 0) or (
                          (v1 > 0 and v2 < 0) and f < 0)):  # 长边
                h0 = a + np.sqrt(r ** 2 - b ** 2)
                mi = h0 / abs(v1 - v2)
                if (v2 > 0):
                    mx = (self.road_length - self.ve[int(t1)][0]) / v2
                else:
                    mx = self.ve[int(t1)][0] / abs(v2)
                if (mi > mx):
                    t_list.append(mx)
                else:
                    t_list.append(mi)

        return t_list

    def neighbor(self, i):  # 第I辆车邻居列表
        t = 0
        v = []
        for j in range(1, self.D):
            if (self.distance(i, j) < self.ve[i][2] and j != i):
                v.append(j)
                t += 1
        return v

    def get_single_v_contribution(self, x, y):  # 以x车为簇头簇内单车辆y贡献值,这里y指的是邻居列表中第y个值
        t = self.connect_time(x)
        m = self.neighbor(x)
        p = m[y]
        if (t[y] < 0.05):
            con = t[y] * (self.cb[p] * (1e-6) / 2)  # 控制量级在10^4
        else:
            con = 0.05 * (self.cb[p] * (1e-6) / 2)
        return con

    def cluster_overall_capacity(self, x):  # 以车辆X为簇头簇内车辆总贡献值
        t = []
        for i in range(len(self.neighbor(x))):
            t.append(self.get_single_v_contribution(x, i))
        m = sum(t)
        q = max(self.connect_time(x))
        if q < 0.05:  # 这里设置0.05是因为设置的任务总完成时间不会超过0.05s
            s = q * (self.cb[x] * (1e-6) / 2)  # 这里1e-7是为了在选取簇头时确保总共献和距离量级相同
        else:
            s = 0.05 * (self.cb[x] * (1e-6) / 2)
        r = s + m
        return r

    def choose_grade(self, x, y):  # x:任务车辆，y:以y作簇头形成的簇
        a = self.cluster_overall_capacity(y)
        b = np.sqrt(abs(self.ve[y][0] - self.tve[x][0]) ** 2 + abs(
            self.ve[y][1] - self.tve[x][1]) ** 2)
        grade = a - b
        return grade

    def UAV0_v(self):  # 0计算无人机覆盖范围内车辆列表
        t = self.ve
        t.tolist()
        UAV0 = []
        for i in range(0, self.D):
            e = []
            e = t[i]
            if (np.sqrt(abs(e[0] - 300) ** 2 + e[1] ** 2) <= self.r_uav):
                UAV0.append(i)
        return UAV0

    def UAV1_v(self):  # 1计算无人机覆盖范围内车辆列表
        t = self.ve
        t.tolist()
        UAV1 = []
        for i in range(0, self.D):
            e = []
            e = t[i]
            if (np.sqrt(abs(e[0] - (self.road_length - self.r_uav)) ** 2 + e[1] ** 2) <= self.r_uav):
                UAV1.append(i)
        return UAV1


    def is_in_ctrl_coverage(self, vehicle_pos):
        """判断位置是否在无人机覆盖范围内（适配十字路口）"""
        x, y = vehicle_pos
        # 总控覆盖范围：整个X方向公路+Y方向公路区域
        return (0 <= x <= self.road_length_x and 0 <= y <= self.road_length_y)

    # *********************判断智能体所可选择RSU,无人机******************************************
    def judge_rsu(self, i):
        e = self.tve
        z = 99
        for d in range(0, self.B):
            x = self.Rsu_location[d]
            if np.sqrt(abs(e[i][0] - x[0]) ** 2 + e[i][1] ** 2) <= self.r_rsu:
                z = d
                break
        return z

    def judge_uav(self, i):
        e = self.tve
        if np.sqrt(abs(e[i][0] - self.r_uav) ** 2 + e[i][1] ** 2) <= np.sqrt(
                abs(e[i][0] - (self.road_length - self.r_uav)) ** 2):
            return 0  # 位于无人机0
        else:
            return 1  # 位于无人机1

    def get_cluster_head(self, ts=None):
        if ts is None:
            ts = []
        u = []  # 总信息：[任务车辆][簇][车辆编号]
        task_list = ts
        for i in range(0, self.task_vehicle):  # 遍历每个任务车辆
            t_w = task_list[i]
            whole_information = task.get_total_task_information(t_w)
            c_list = []  # 当前任务车辆的簇列表
            t = []  # 候选车辆池（原逻辑保留，确保在通信范围内）
            # ---------------------- 确定候选车辆池t ----------------------
            dist_to_uav0 = np.sqrt(abs(self.tve[i][0] - self.r_uav) ** 2 + self.tve[i][1] ** 2)
            dist_to_uav1 = np.sqrt(abs((self.road_length - self.r_uav) - self.tve[i][0]) ** 2 + self.tve[i][1] ** 2)
            if dist_to_uav0 <= self.r_uav and dist_to_uav1 > self.r_uav:
                t = copy.deepcopy(self.UAV0_v())
            elif dist_to_uav0 > self.r_uav and dist_to_uav1 <= self.r_uav:
                t = copy.deepcopy(self.UAV1_v())
            else:
                t = [x for x in range(self.D)]
            if not t:  # 无候选车辆，直接返回空
                u.append(c_list)
                continue

            # ---------------------- 动态确定簇数量 ----------------------
            min_cluster_size = 6  # 每簇至少1个簇头+5个成员
            max_clusters = 5  # 最多5个簇（与原输出兼容）
            num_clusters = min(max_clusters, len(t) // min_cluster_size)
            num_clusters = max(num_clusters, 1)  # 至少1个簇

            # ---------------------- 簇头选择（综合多指标） ----------------------
            cluster_heads = []
            for _ in range(num_clusters):
                if not t:  # 候选车辆不足，提前结束
                    break
                # 计算每个候选车辆的综合得分（优先级+计算能力+距离）
                scores = []
                for ve_id in t:
                    # 1. 原优先级
                    grade = self.choose_grade(i, ve_id)
                    # 2. 计算能力
                    cp = self.cb[ve_id] / 1e9  # 归一化到[0,1]
                    # 3. 与任务车辆的距离
                    dist = np.sqrt(
                        (self.tve[i][0] - self.ve[ve_id][0]) ** 2 + (self.tve[i][1] - self.ve[ve_id][1]) ** 2)
                    dist_norm = 1 - min(dist / self.r_uav, 1.0)  # 距离越近得分越高
                    # 综合得分（权重可调整）
                    total_score = 0.5 * grade + 0.3 * cp + 0.2 * dist_norm
                    scores.append((-total_score, ve_id))  # 负号用于升序排序取最小值
                scores.sort()  # 升序排序，第一个为最大得分
                best_head = scores[0][1]
                cluster_heads.append(best_head)
                t.remove(best_head)  # 簇头从候选池移除

            # ---------------------- 簇成员筛选 ----------------------
            for head in cluster_heads:
                w_list = [head]  # 当前簇：先加入簇头
                # 获取簇头的邻居和连接时间
                n_list = self.neighbor(head)
                ct_list = self.connect_time(head)
                # 任务最大时延（用于筛选连接时间）
                delay = [info[2] for info in whole_information]
                max_delay = np.max(delay) if delay else 0.1
                # 筛选符合条件的成员（在候选池t中+连接时间足够）
                valid_members = []
                for d in range(len(n_list)):
                    member_id = n_list[d]
                    if member_id in t and ct_list[d] >= 0.3 * max_delay:
                        # 成员贡献能力
                        contribution = self.get_single_v_contribution(head, d)
                        valid_members.append((-contribution, member_id))  # 负号用于排序
                # 按贡献能力降序排序，取前5个
                valid_members.sort()
                selected_members = [m[1] for m in valid_members[:5]]
                # 加入簇并从候选池移除
                w_list.extend(selected_members)
                for m in selected_members:
                    if m in t:
                        t.remove(m)
                # 确保簇至少有6个成员（否则视为无效簇）
                if len(w_list) >= 6:
                    c_list.append(w_list)

            # 确保簇数量不超过5个
            c_list = c_list[:5]
            u.append(c_list)
        return u
    # ************************延迟处理部分********************************************************
    def local_latency_in(self, task_vehicle, task_information=None):  # 任务车辆x所处理入口任务延迟
        if task_information is None:
            task_information = []
        t = task_information[0]
        y = t[0]  # 入口任务
        d = y[1]*self.s / (self.tve[task_vehicle][2])
        return d

    def local_energy_in(self, task_vehicle, task_information=None):  # 任务车辆x所处理入口任务能耗
        if task_information is None:
            task_information = []
        t = task_information[0]
        y = t[0]  # 入口任务
        power_coefficient = 1e-10
        # e = y[1] * (self.tve[task_vehicle][2]) ** 2
        e = y[1] * power_coefficient
        # print("energy_list-in", e)
        return e

    # def local_energy_in(self, task_vehicle, task_information=None):
    #     """计算入口任务本地能耗，保持原有接口"""
    #     if task_information is None:
    #         task_information = []
    #
    #     # 从task_information中提取入口任务信息
    #     entrance_task = task_information[0][0]
    #     C_in = entrance_task[1]
    #
    #     # 根据论文公式：E_k^l = t_k * C_in * (f_k^l)^2
    #     t_k = 1e-39  # 硬件相关影响因子
    #     f_k_l = self.tve[task_vehicle][2]
    #     e = t_k * C_in * (f_k_l ** 2)
    #
    #     return e

    def local_latency_out(self, task_vehicle, task_information=None):  # 任务车辆x所处理出口任务延迟
        if task_information is None:
            task_information = []
        t = task_information[0]
        y = t[1]  # 出口任务
        d = y[1]*self.s/ (self.tve[task_vehicle][2])
        return d

    def local_energy_out(self, task_vehicle, task_information=None):  # 任务车辆x所处理出口任务能耗
        if task_information is None:
            task_information = []
        t = task_information[0]
        y = t[1]  # 出口任务
        # e = y[1] * (self.tve[task_vehicle][2]) ** 2
        power_coefficient = 1e-10
        e = y[1] * power_coefficient
        # print("energy_list-out", e)
        return e

    # def local_energy_out(self, task_vehicle, task_information=None):
    #     """计算出口任务本地能耗，保持原有接口"""
    #     if task_information is None:
    #         task_information = []
    #
    #     # 从task_information中提取出口任务信息
    #     exit_task = task_information[0][1]
    #     C_out = exit_task[1]
    #
    #     # 根据论文公式：E_k^l = t_k * C_out * (f_k^l)^2
    #     t_k = 1e-39
    #     f_k_l = self.tve[task_vehicle][2]
    #     e = t_k * C_out * (f_k_l ** 2)
    #
    #     return e


    def Rsu_latency(self, cm, t_in=None, all_t_in=None):
        """计算RSU延迟，保持原有接口"""
        if all_t_in is None:
            all_t_in = []
        if t_in is None:
            t_in = []

        # t_in是子任务列表（五元组）
        # all_t_in是任务总信息 [总输入, 总计算量, 最小截止时间]
        rr = cm  # RSU计算频率

        time_list = []  # 存储每个子任务的完成时间
        total_transmission_time = 0
        total_computation_time = 0

        # 遍历所有子任务
        for i in range(len(t_in)):
            subtask = t_in[i]  # 子任务五元组 [D_s, I_s, C_s, O_s, T_s_max]
            D_s, I_s, C_s, O_s, T_s_max = subtask

            # 传输时延：(D_s + I_s) / R_k,i
            transmission_time = (D_s + I_s) *self.s/ (self.tran_V2I)

            # 计算时延：C_s / f_i
            computation_time = C_s *self.s/ (rr)

            # 子任务完成时间 = 传输 + 计算
            subtask_time = transmission_time + computation_time
            time_list.append(subtask_time)

            total_transmission_time += transmission_time
            total_computation_time += computation_time

        # 总时延（最后一个元素为总时延）
        # 注意：这里需要根据子任务依赖关系调整，但为保持接口不变，使用简单求和
        total_time = total_transmission_time + total_computation_time
        time_list.append(total_time)

        return time_list

    # def Rsu_energy(self, cm, e_in=None, all_e_in=None):
    #     """计算RSU能耗，保持原有接口"""
    #     if all_e_in is None:
    #         all_e_in = []
    #     if e_in is None:
    #         e_in = []
    #
    #     rr = cm  # RSU计算频率
    #
    #     energy_list = []  # 存储每个子任务的能耗
    #     total_transmission_energy = 0
    #     total_computation_energy = 0
    #
    #     # 遍历所有子任务
    #     for i in range(len(e_in)):
    #         subtask = e_in[i]  # 子任务五元组
    #         D_s, I_s, C_s, O_s, T_s_max = subtask
    #
    #         # 传输能耗：p_k * (D_s + I_s) / R_k,i
    #         transmission_energy = self.transmit_power * ((D_s + I_s) / self.tran_V2I)
    #
    #         # 计算能耗：t_i * C_s * (f_i)^2
    #         t_i = 1e-39  # 与RSU硬件相关的影响因子
    #         computation_energy = t_i * C_s * (rr ** 2)
    #
    #         # 子任务总能耗
    #         subtask_energy = transmission_energy + computation_energy
    #         energy_list.append(subtask_energy)
    #
    #         total_transmission_energy += transmission_energy
    #         total_computation_energy += computation_energy
    #     # 总能耗（最后一个元素为总能耗）
    #     total_energy = total_transmission_energy + total_computation_energy
    #     energy_list.append(total_energy)
    #
    #     return energy_list
    def Rsu_energy(self, cm, e_in=None, all_e_in=None):
        """计算RSU能耗，保持原有接口"""
        if all_e_in is None:
            all_e_in = []
        if e_in is None:
            e_in = []

        rr = cm  # RSU计算频率

        energy_list = []  # 存储每个子任务的能耗
        total_transmission_energy = 0
        total_computation_energy = 0


        # 遍历所有子任务
        for i in range(len(e_in)):
            subtask = e_in[i]  # 子任务五元组
            D_s, I_s, C_s, O_s, T_s_max = subtask

            # 传输能耗：p_k * (D_s + I_s) / R_k,i
            transmission_energy = self.transmit_power * ((D_s + I_s) / self.tran_V2I)

            # # 计算能耗：t_i * C_s * (f_i)^2
            # t_i = 1e-39  # 与RSU硬件相关的影响因子
            # computation_energy = t_i * C_s * (rr ** 2)
            power_coefficient = 1e-10
            computation_energy = C_s * power_coefficient

            # 子任务总能耗
            subtask_energy = transmission_energy + computation_energy
            energy_list.append(subtask_energy)

            total_transmission_energy += transmission_energy
            total_computation_energy += computation_energy
        # 总能耗（最后一个元素为总能耗）
        total_energy = total_transmission_energy + total_computation_energy
        energy_list.append(total_energy)

        # print("energy_list-RSU", energy_list)

        return energy_list


    def uav_latency(self, cm, t_in=None, all_t_in=None):
        """计算无人机延迟，保持原有接口"""
        if all_t_in is None:
            all_t_in = []
        if t_in is None:
            t_in = []

        rr = cm  # 无人机计算频率

        time_list = []
        total_transmission_time = 0
        total_computation_time = 0

        # 遍历所有子任务
        for i in range(len(t_in)):
            subtask = t_in[i]  # 子任务五元组
            D_s, I_s, C_s, O_s, T_s_max = subtask

            # 传输时延：(D_s + I_s) / R_k,u
            transmission_time = (D_s + I_s) *self.s/ (self.tran_v2u)

            # 计算时延：C_s / f_u
            computation_time = C_s*self.s / (rr)

            subtask_time = transmission_time + computation_time
            time_list.append(subtask_time)

            total_transmission_time += transmission_time
            total_computation_time += computation_time
        total_time = total_transmission_time + total_computation_time
        time_list.append(total_time)

        return time_list


    def uav_energy(self, cm, e_in=None, all_e_in=None):
        """计算无人机能耗，保持原有接口"""
        if all_e_in is None:
            all_e_in = []
        if e_in is None:
            e_in = []

        rr = cm  # 无人机计算频率

        energy_list = []
        total_transmission_energy = 0
        total_computation_energy = 0

        # 遍历所有子任务
        for i in range(len(e_in)):
            subtask = e_in[i]  # 子任务五元组
            D_s, I_s, C_s, O_s, T_s_max = subtask

            # 传输能耗：p_k * (D_s + I_s) / R_k,u
            transmission_energy = self.transmit_power * ((D_s + I_s) / self.tran_v2u)

            # 计算能耗：t_u * C_s * (f_u)^2
            # t_u = 1e-39  # 与无人机硬件相关的影响因子
            # computation_energy = t_u * C_s * (rr ** 2)
            power_coefficient = 1e-10
            computation_energy = C_s * power_coefficient

            subtask_energy = transmission_energy + computation_energy
            energy_list.append(subtask_energy)

            total_transmission_energy += transmission_energy
            total_computation_energy += computation_energy
        # # 添加无人机巡航能耗（简化模型）
        # flight_time = 1.0  # 假设飞行时间
        # flight_energy = self.calculate_uav_cruise_energy(flight_time)
        flight_energy=0
        total_energy = total_transmission_energy + total_computation_energy + flight_energy
        energy_list.append(total_energy)

        # print("energy_list-UAV", energy_list)

        return energy_list



    def cluster_latency(self, ve, ve_cluster=None, t_in=None, all_t_in=None):
        """计算车辆簇延迟，保持原有接口"""
        if all_t_in is None:
            all_t_in = []
        if ve_cluster is None:
            ve_cluster = []
        if t_in is None:
            t_in = []

        time_list = []

        if len(ve_cluster) == 0:
            # 无可用簇，本地计算所有子任务
            for subtask in t_in:
                D_s, I_s, C_s, O_s, T_s_max = subtask
                computation_time = C_s *self.s/ (self.tve[ve][2])
                time_list.append(computation_time)

            total_time = sum(time_list)
            time_list.append(total_time)
        else:
            # 有可用簇，使用簇头计算
            cluster_head = ve_cluster[0]
            f_c = self.cb[cluster_head] if self.cb[cluster_head] > 0 else self.tve[ve][2]

            total_time = 0
            for i, subtask in enumerate(t_in):
                D_s, I_s, C_s, O_s, T_s_max = subtask
                # 传输时延：(D_s + I_s) / R_k,c
                transmission_time = (D_s + I_s) *self.s/ (self.tran_v2v)

                # 计算时延：C_s / f_c
                computation_time = C_s*self.s / (f_c)

                # 对于非第一个子任务，需要考虑前一个子任务的输出传输
                if i > 0:
                    # 假设簇内传输时延可以忽略，或者包含在computation_time中
                    pass

                subtask_time = transmission_time + computation_time
                time_list.append(subtask_time)
                total_time += subtask_time

            time_list.append(total_time)

        return time_list

    def cluster_energy(self, ve, ve_cluster=None, e_in=None, all_e_in=None):
        """计算车辆簇能耗，保持原有接口"""
        if all_e_in is None:
            all_e_in = []
        if ve_cluster is None:
            ve_cluster = []
        if e_in is None:
            e_in = []

        energy_list = []


        if len(ve_cluster) == 0:
            # 无可用簇，本地计算
            for subtask in e_in:
                D_s, I_s, C_s, O_s, T_s_max = subtask
                # t_v = 1e-39 # 车辆硬件影响因子
                # f_v = self.tve[ve][2]
                # computation_energy = t_v * C_s * (f_v ** 2)
                power_coefficient = 1e-10
                computation_energy=C_s*power_coefficient
                energy_list.append(computation_energy)

            total_energy = sum(energy_list)
            energy_list.append(total_energy)
        else:
            # 有可用簇
            cluster_head = ve_cluster[0]
            f_c = self.cb[cluster_head] if self.cb[cluster_head] > 0 else self.tve[ve][2]

            total_energy = 0
            for i, subtask in enumerate(e_in):
                D_s, I_s, C_s, O_s, T_s_max = subtask
                # 传输能耗：p_k * (D_s + I_s) / R_k,c
                transmission_energy = self.transmit_power * ((D_s + I_s) / self.tran_v2v)

                # 计算能耗：t_c * C_s * (f_c)^2
                # t_c = 1e-39  # 簇头硬件影响因子
                # computation_energy = t_c * C_s * (f_c ** 2)
                power_coefficient = 1e-10
                computation_energy = C_s * power_coefficient

                subtask_energy = transmission_energy + computation_energy
                energy_list.append(subtask_energy)
                total_energy += subtask_energy

            energy_list.append(total_energy)

            # print("energy_list-v", energy_list)

        return energy_list






    def v_utility(self, ex_price, ve, ve_cluster=None, delay_list=None, task_list=None,
                  task_all=None, energy_list=None):

        # 权重因子
        self.phi = 0.4
        self.psi = 0.6

        p1 = 2e-4  # 任务车辆支付给服务端的通信单价2e-5
        p3 = 2e-7  # 车辆集群通信租赁成本
        p4_comp = 7.5e-5  # 任务车辆支付给服务端的计算单价1.5e-5
        p6 = 1.5e-7  # 车辆集群计算租赁成本
        p_v = 0

        if task_all is None:
            task_all = []
        if ve_cluster is None:
            ve_cluster = []
        if delay_list is None:
            delay_list = []
        if energy_list is None:
            energy_list = []
        if task_list is None:
            task_list = []

        if not ve_cluster:
            ex = -0.1
            re = -0.1
            r_l = []
            return ex, re, r_l

        # 初始化
        jp = 0
        total_reward = 0
        ex_reward = 0
        reward_v = np.zeros([6, 4])  # 包含5辆备选车+簇头: [车辆编号, 单价奖励, 额外奖励, 总奖励]

        # 获取车辆计算能力并排序
        compute_capabilities = []
        for ve_id in ve_cluster:
            compute_capabilities.append([self.cb[ve_id], ve_id])
        compute_capabilities.sort(reverse=True)  # 按计算能力降序排列

        # 处理每个子任务
        for i, task in enumerate(task_list):
            if i >= len(compute_capabilities):
                break

            ve_id = compute_capabilities[i][1]
            # 任务数据量(D_s + I_s)和计算量(C_s)
            data_size = task[0]  # D_s + I_s
            compute_cycles = task[1]  # C_s

            # 计算本地处理时延和能耗（用于比较）
            local_delay = compute_cycles / self.tve[ve][2]
            power_coefficient = 1e-10
            local_energy = compute_cycles * power_coefficient

            # 实际卸载时延和能耗
            actual_delay = delay_list[i] if i < len(delay_list) else 0
            actual_energy = energy_list[i] if i < len(energy_list) else 0

            # 通信效用：p1 * 传输数据量 - p3 * 传输数据量
            comm_utility = p1 * data_size - p3 * data_size

            # 计算效用：p4_comp * 计算量 - p6 * 计算量 + p_v * 计算量
            comp_utility = p4_comp * compute_cycles - p6 * compute_cycles + p_v * compute_cycles

            # 总效用（不含惩罚项）
            utility = comm_utility + comp_utility

            # 最终奖励 = 效用 - φ*时延 - ψ*能耗
            reward = utility - self.phi * actual_delay - self.psi * actual_energy

            # 存储结果
            reward_v[i][0] = ve_id
            reward_v[i][1] = utility  # 存储效用部分（不含惩罚）
            reward_v[i][2] = reward  # 存储总奖励
            # reward_v[i][3] = reward  # 总奖励（与reward相同，保持结构）

            total_reward += reward

            # 检查是否为簇头
            if ve_id == ve_cluster[0]:
                jp += 1

        # 如果簇头没有处理任务，给与基础组织奖励
        if jp == 0 and len(task_list) < len(compute_capabilities):
            ch_id = ve_cluster[0]
            # 簇头的基础组织奖励（论文中未明确定义，保持原有逻辑）
            base_reward = 0.5  # 可根据实际情况调整
            reward_v[len(task_list)][0] = ch_id
            reward_v[len(task_list)][2] = base_reward
            reward_v[len(task_list)][3] = base_reward
            total_reward += base_reward

        return total_reward, ex_reward, reward_v

    def uav_utility(self, ve, uav_id, delay_list=None, task_all=None, energy_list=None):

        # 权重因子
        self.phi = 0.4
        self.psi = 0.6

        p1 = 2e-4  # 任务车辆支付给服务端的通信单价
        p2 = 1e-5  # 无人机通信租赁成本
        p4_comp = 7.5e-5  # 任务车辆支付给服务端的计算单价
        p5 = 0.7e-5  # 无人机计算租赁成本
        p_u = 0

        if energy_list is None:
            energy_list = []
        if delay_list is None:
            delay_list = []
        if task_all is None:
            task_all = []

        reward_uav = np.zeros([2, 3])  # [基站编号, 效用, 总奖励]

        # 任务数据量和计算量
        data_size = task_all[0]  # D_s + I_s
        compute_cycles = task_all[1]  # C_s

        # 本地处理时延和能耗（用于比较）
        local_delay = compute_cycles / self.tve[ve][2]
        power_coefficient = 1e-10
        local_energy = compute_cycles * power_coefficient

        # 实际卸载时延和能耗
        actual_delay = delay_list[-1] if delay_list else 0
        actual_energy = energy_list[-1] if energy_list else 0

        # 通信效用
        comm_utility = p1 * data_size - p2 * data_size

        # 计算效用
        comp_utility = p4_comp * compute_cycles - p5 * compute_cycles + p_u * compute_cycles

        # 总效用
        utility = comm_utility + comp_utility

        # 最终奖励 = 效用 - φ*时延 - ψ*能耗
        reward = utility - self.phi * actual_delay - self.psi * actual_energy

        # 存储结果
        reward_uav[0][0] = uav_id
        reward_uav[0][1] = utility
        reward_uav[0][2] = reward

        return reward_uav

    def Rsu_utility(self, ve, rsu_id, delay_list=None, task_all=None, energy_list=None):

        # 权重因子
        self.phi = 0.4
        self.psi = 0.6

        p1 = 2e-4  # 任务车辆支付给服务端的通信单价
        p4_com = 0.5e-5  # RSU通信租赁成本
        p4_comp = 7.5e-5  # 任务车辆支付给服务端的计算单价
        p7 = 0.2e-5  # RSU计算租赁成本
        p_z = 0

        if energy_list is None:
            energy_list = []
        if delay_list is None:
            delay_list = []
        if task_all is None:
            task_all = []

        reward_rsu = np.zeros([8, 4])  # [RSU编号, 效用, 额外奖励, 总奖励]

        # 任务数据量和计算量
        data_size = task_all[0]  # D_s + I_s
        compute_cycles = task_all[1]  # C_s

        # 本地处理时延和能耗
        local_delay = compute_cycles / self.tve[ve][2]
        power_coefficient = 1e-10
        local_energy = compute_cycles * power_coefficient

        # 实际卸载时延和能耗
        actual_delay = delay_list[-1] if delay_list else 0
        actual_energy = energy_list[-1] if energy_list else 0

        # 通信效用
        comm_utility = p1 * data_size - p4_com * data_size

        # 计算效用
        comp_utility = p4_comp * compute_cycles - p7 * compute_cycles + p_z * compute_cycles

        # 总效用
        utility = comm_utility + comp_utility

        # 最终奖励 = 效用 - φ*时延 - ψ*能耗
        reward = utility - self.phi * actual_delay - self.psi * actual_energy

        # 存储结果
        reward_rsu[rsu_id][0] = rsu_id
        reward_rsu[rsu_id][1] = utility
        reward_rsu[rsu_id][2] = reward  # 奖励
        # reward_rsu[rsu_id][3] = reward

        return reward_rsu



    def get_agent_action_space(self, agent):
        global ac_space
        if agent == 0:
            ac_space = 7 ** (len(self.v0) - 1)  # 2决策分配到BUAV,+分配到C又有5种额外增益参数选取
        elif agent == 1:
            ac_space = 7 ** (len(self.v1) - 1)
        elif agent == 2:
            ac_space = 7 ** (len(self.v2) - 1)
        elif agent == 3:
            ac_space = 7 ** (len(self.v3) - 1)
        elif agent == 4:
            ac_space = 7 ** (len(self.v4) - 1)
        return ac_space

    # def get_action_dim(self):
    #     a_d = [len(self.v0)+1, len(self.v1)+1, len(self.v2)+1, len(self.v3)+1, len(self.v4)+1]
    #     return a_d

    # def get_agent_state_dim(self):
    #     x = [len(self.get_agaent0_state()), len(self.get_agaent1_state()), len(self.get_agaent2_state()),
    #          len(self.get_agaent3_state()), len(self.get_agaent4_state())]
    #     return x

    def get_agaent0_state(self):  # 只加变化量 维度即数据长度
        self.agent0_state = np.append(self.get_task_size(self.v0), self.get_v_location(0))  # 任务大小,辅助车辆位置坐标
        self.agent0_state = np.append(self.agent0_state, self.tve[0][0])
        self.agent0_state = np.append(self.agent0_state, self.tve[0][1])  # 任务车辆坐标

        return self.agent0_state

    def get_agaent1_state(self):  # 只加变化量
        self.agent1_state = np.append(self.get_task_size(self.v1), self.get_v_location(1))  # 任务大小,辅助车辆位置坐标
        self.agent1_state = np.append(self.agent1_state, self.tve[1][0])
        self.agent1_state = np.append(self.agent1_state, self.tve[1][1])  # 任务车辆坐标
        return self.agent1_state

    def get_agaent2_state(self):  # 只加变化量
        self.agent2_state = np.append(self.get_task_size(self.v2), self.get_v_location(2))  # 任务大小,辅助车辆位置坐标
        self.agent2_state = np.append(self.agent2_state, self.tve[2][0])
        self.agent2_state = np.append(self.agent2_state, self.tve[2][1])  # 任务车辆坐标
        return self.agent2_state

    def get_agaent3_state(self):  # 只加变化量
        self.agent3_state = np.append(self.get_task_size(self.v3), self.get_v_location(3))  # 任务大小,辅助车辆位置坐标
        self.agent3_state = np.append(self.agent3_state, self.tve[3][0])
        self.agent3_state = np.append(self.agent3_state, self.tve[3][1])  # 任务车辆坐标
        return self.agent3_state

    def get_agaent4_state(self):  # 只加变化量
        self.agent4_state = np.append(self.get_task_size(self.v4), self.get_v_location(4))  # 任务大小,辅助车辆位置坐标
        self.agent4_state = np.append(self.agent4_state, self.tve[4][0])
        self.agent4_state = np.append(self.agent4_state, self.tve[4][1])  # 任务车辆坐标
        return self.agent4_state

    def get_task_size(self, t=None):
        if t is None:
            t = []
        task_size = np.zeros([1, 25])
        m = 0
        for i in range(1, len(t)):
            p = t[i]
            for j in range(0, len(p)):
                u = p[j]
                task_size[0][m] = u[1]
                m += 1
        return task_size

    def get_v_location(self, i):  # 任务车辆编号
        l_i = np.zeros([1, 400])
        m = 0
        t = []
        if (np.sqrt(abs(self.tve[i][0] - self.r_uav) ** 2 + self.tve[i][1] ** 2) <= self.r_uav and np.sqrt(
                abs((self.road_length - self.r_uav) - self.tve[i][0]) ** 2 + self.tve[i][1] ** 2) > self.r_uav):
            t = self.UAV0_v()  # 只位于0基站覆盖范围内
        elif (np.sqrt(abs(self.tve[i][0] - self.r_uav) ** 2 + self.tve[i][1] ** 2) > self.r_uav and np.sqrt(
                abs((self.road_length - self.r_uav) - self.tve[i][0]) ** 2 + self.tve[i][1] ** 2) <= self.r_uav):
            t = self.UAV1_v()  # 只位于1基站覆盖范围内
        elif (np.sqrt(abs(self.tve[i][0] - self.r_uav) ** 2 + self.tve[i][1] ** 2) <= self.r_uav and np.sqrt(
                abs((self.road_length - self.r_uav) - self.tve[i][0]) ** 2 + self.tve[i][1] ** 2) <= self.r_uav):
            t = [x for x in range(self.D)]  # 位于交叉区域
        for i in range(0, len(t)):
            l_i[0][m] = self.ve[t[i]][0]
            l_i[0][m + 1] = self.ve[t[i]][1]
            m += 2
        return l_i

    def judge_rsu_dis(self, t_v):
        global a
        for i in range(0, self.B):
            distance = np.sqrt(abs(self.tve[t_v][0] - self.Rsu_location[i][0]) ** 2 + abs(
                self.tve[t_v][1] - self.Rsu_location[i][1]) ** 2)
            if distance < self.r_rsu:
                a = i
                break
        return a

    def renew_position(self):
        """更新所有实体位置：车辆移动+RSU静止+无人机轨迹优化（保留正确版本，删除重复旧版本）"""
        # 1. 更新普通车辆位置
        for i in range(V_information.N):
            # X方向移动（边界循环）
            self.ve[i][0] += self.ve[i][3] * self.T
            if self.ve[i][0] < 0:
                self.ve[i][0] = self.road_length_x + self.ve[i][0]
            elif self.ve[i][0] > self.road_length_x:
                self.ve[i][0] = self.ve[i][0] - self.road_length_x

            # Y方向移动（边界循环）
            self.ve[i][1] += self.ve[i][3] * self.T
            if self.ve[i][1] < 0:
                self.ve[i][1] = self.road_length_y + self.ve[i][1]
            elif self.ve[i][1] > self.road_length_y:
                self.ve[i][1] = self.ve[i][1] - self.road_length_y

        # 2. 更新任务车辆位置（与普通车辆同步）
        for i in range(self.task_vehicle):
            self.tve[i][0] = self.ve[i][0]
            self.tve[i][1] = self.ve[i][1]

        # 3. RSU位置保持不变（无需更新）

        # 4. 调用改进PSO优化的无人机轨迹更新
        self.optimize_uav_trajectory()

        # 5. 更新任务与负载状态
        self.update_task_status()
        self.update_load_status()


    def renew_car(self):  # 车辆越界重新生成车辆
        for i in range(V_information.N):
            if (self.ve[i][0] > self.road_length_x or self.ve[i][0] < 0 or
                    self.ve[i][1] > self.road_length_y or self.ve[i][1] < 0):
                self.ve[i][1] = np.random.uniform(0, 21)  # 纵坐标
                self.ve[i][2] = np.random.uniform(30, 40)  # 通信半径
                self.cb[i] = np.random.randint(0.7e9, 0.9e9)  # 计算速度 0.7-0.9Gcycle/s
                a = np.random.randint(0, 2)
                if a == 0:
                    self.ve[i][0] = np.random.uniform(0, 100)  # 横坐标 从入口处生成
                    if (self.ve[i][1] < 3.5 and self.ve[i][1] > 0):
                        m = np.random.uniform(16.66, 33.33)
                        self.ve[i][3] = m
                    elif (self.ve[i][1] < 7 and self.ve[i][1] > 3.5):
                        m = np.random.uniform(25, 33.33)
                        self.ve[i][3] = m
                    elif (self.ve[i][1] < 10.5 and self.ve[i][1] > 7):
                        m = np.random.uniform(30.55, 33.33)
                        self.ve[i][3] = m
                if a == 1:
                    self.ve[i][0] = np.random.uniform(900, self.road_length)  # 横坐标 从出口处生成
                    if (self.ve[i][1] < 14 and self.ve[i][1] > 10.5):
                        m = np.random.uniform(-33.33, -16.66)
                        self.ve[i][3] = m
                    elif (self.ve[i][1] < 17.5 and self.ve[i][1] > 14):
                        m = np.random.uniform(-33.33, -25)
                        self.ve[i][3] = m
                    elif (self.ve[i][1] < 21 and self.ve[i][1] > 17.5):
                        m = np.random.uniform(-33.33, -30.55)
                        self.ve[i][3] = m
        for i in range(self.task_vehicle):
            if (self.tve[i][0] > self.road_length or self.tve[i][0] < 0):
                self.tve[i][1] = np.random.uniform(0, 24)
                self.tve[i][2] = np.random.randint(0.6e9, 0.72e9)  # 计算速度 0.7-0.8Gcycles/s
                a = np.random.randint(0, 2)
                if a == 0:
                    self.tve[i][0] = np.random.uniform(0, 100)  # 横坐标 从入口处生成
                    if (self.tve[i][1] < 3.5 and self.tve[i][1] > 0):
                        m = np.random.uniform(16.66, 33.33)
                        self.tve[i][3] = m
                    elif (self.tve[i][1] < 7 and self.tve[i][1] > 3.5):
                        m = np.random.uniform(25, 33.33)
                        self.tve[i][3] = m
                    elif (self.tve[i][1] < 10.5 and self.tve[i][1] > 7):
                        m = np.random.uniform(30.55, 33.33)
                        self.tve[i][3] = m
                if a == 1:
                    self.tve[i][0] = np.random.uniform(900, self.road_length)  # 横坐标 从出口处生成
                    if (self.tve[i][1] < 14 and self.tve[i][1] > 10.5):
                        m = np.random.uniform(-33.33, -16.66)
                        self.tve[i][3] = m
                    elif (self.tve[i][1] < 17.5 and self.tve[i][1] > 14):
                        m = np.random.uniform(-33.33, -25)
                        self.ve[i][3] = m
                    elif (self.tve[i][1] < 21 and self.tve[i][1] > 17.5):
                        m = np.random.uniform(-33.33, -30.55)
                        self.tve[i][3] = m

    def permute(self, nums):  # 求全排列
        length = len(nums)
        result = [[[nums[0]]]]
        if length == 1:
            return result[0]
        else:
            for i in range(1, length):  # 循环lengh-1次，也就是算到所有元素加入。
                result.append(list())  # 加入一个新列表，用于存储加入一个新元素后生成的全排列
                for j in result[i - 1]:  # 遍历上一个全排列
                    for k in range(len(j) + 1):  # 循环len(j)+1次，也就是可插入新元素的位置为len(j)+1个
                        j.insert(k, nums[i])  # 以上一个排列为基础，插入新元素
                        result[i].append(list(j))  # 将得到的新的排列插入到新生成的列表中。
                        j.pop(k)  # 弹出插入的元素，使上一个全排列的内容恢复到原来状态。
            return result[length - 1]


    def opt_ve_offlod(self, ex_price, ve, ac_option=None, all_t_in=None):
        if ac_option is None:
            ac_option = []
        if all_t_in is None:
            all_t_in = []
        l = []
        r = []
        er = []
        e = []

        # 权重因子
        phi = 0.4  # 时延权重因子
        psi = 0.6  # 能耗权重因子

        for i in range(len(ac_option)):
            teml = []  # 放时延
            temr = []  # 放总奖励
            temer = []  # 放综合奖励
            teme = []  # 临时存储能耗
            tem_rew_l = []  # 放总奖励列表

            max_rew_l = []
            max_er = 0
            max_r = 0
            min_l = 0
            min_e = 0

            choose = ac_option[i]
            t_l = self.permute(choose[0])  # 任务列表
            c_l = choose[1]  # 簇列表

            for j in range(len(t_l)):
                # 计算时延和能耗
                delay = self.cluster_latency(ve, c_l, t_l[j], all_t_in[i])
                energy = self.cluster_energy(ve, c_l, t_l[j], all_t_in[i])

                # 获取系统效用（U_k）和综合奖励（F(t)）
                utility = self.v_utility(ex_price, ve, c_l, delay, t_l[j], all_t_in[i], energy)

                # 从utility中提取结果
                # utility返回的是 (total_reward, ex_reward, reward_v)
                total_reward = utility[0]  # 总奖励（对应U_k）
                ex_reward = utility[1]  # 额外奖励
                reward_v = utility[2]  # 奖励列表

                # 计算综合奖励（按照论文公式 F(t) = U_k - φT_k^total - ψE_k^total）
                total_delay = delay[-1] if delay else 0
                total_energy = energy[-1] if energy else 0
                comprehensive_reward = total_reward - phi * total_delay - psi * total_energy

                teml.append(total_delay)
                temr.append(total_reward)  # 存储系统效用U_k
                temer.append(comprehensive_reward)  # 存储综合奖励F(t)
                teme.append(total_energy)  # 存储总能耗
                tem_rew_l.append(reward_v)  # 存储奖励列表

            # 根据综合奖励选择最优方案
            # 综合奖励 = U_k - φ*时延 - ψ*能耗
            max_er = max(temer)
            index = temer.index(max_er)

            max_r = temr[index]  # 对应的系统效用U_k
            min_l = teml[index]  # 对应的时延
            min_e = teme[index]  # 对应的能耗
            max_rew_l = tem_rew_l[index]

            # 执行最优卸载决策（条件可调整）
            if max_er > 0:  # 综合奖励大于0才执行
                self.delete_task_infomarion(ve, all_t_in[i])  # 清任务大小
                # 清车辆算力（保持原逻辑）
                for idx in range(len(choose[0])):
                    if idx < len(max_rew_l) and len(max_rew_l[idx]) > 0:
                        # 确保有车辆编号信息
                        try:
                            vehicle_id = int(max_rew_l[idx][0])
                            if vehicle_id < len(self.cb):
                                self.cb[vehicle_id] = 0
                        except (ValueError, IndexError, TypeError):
                            # 如果解析失败，跳过
                            continue

            l.append(min_l)
            r.append(max_r)
            er.append(max_er)
            e.append(min_e)

        return l, r, er, e  # 返还总时延，总效用，综合奖励，总能耗

    def ex_price(self, action):
        if action <= 0.25:
            return 2.5e-7
        elif action > 0.25 and action <= 0.5:
            return 5e-7
        elif action > 0.5 and action <= 0.75:
            return 7.5e-7
        elif action > 0.75 and action <= 1:
            return 1e-6

    def delete_task_infomarion(self, ve, all_t_in=None):
        if all_t_in is None:
            all_t_in = []
        if ve == 0:
            t_index = self.v0_a.index(all_t_in)
            p = self.v0[t_index + 1]
            for i in range(len(p)):
                tmm = p[i]
                tmm[1] = 0
        elif ve == 1:
            t_index = self.v1_a.index(all_t_in)
            p = self.v1[t_index + 1]
            for i in range(len(p)):
                tmm = p[i]
                tmm[1] = 0
        elif ve == 2:
            t_index = self.v2_a.index(all_t_in)
            p = self.v2[t_index + 1]
            for i in range(len(p)):
                tmm = p[i]
                tmm[1] = 0
        elif ve == 3:
            t_index = self.v3_a.index(all_t_in)
            p = self.v3[t_index + 1]
            for i in range(len(p)):
                tmm = p[i]
                tmm[1] = 0
        elif ve == 4:
            t_index = self.v4_a.index(all_t_in)
            p = self.v4[t_index + 1]
            for i in range(len(p)):
                tmm = p[i]
                tmm[1] = 0
