import torch
import torch.nn.functional as F
import numpy as np
import copy
from networks_MASAC import Actor, Critic_MADDPG  


class MASAC(object):
    def __init__(self, args, agent_id):
        self.N = args.N
        self.agent_id = agent_id
        self.max_action = args.max_action
        self.action_dim = args.action_dim_n[agent_id]

        # 超参数
        self.lr_a = args.lr_a
        self.lr_c = args.lr_c
        self.gamma = args.gamma
        self.tau = args.tau
        self.use_grad_clip = args.use_grad_clip
        self.alpha = args.alpha  # 熵温度参数，控制探索-利用权衡

        # 网络初始化（Actor输出高斯分布的均值和标准差）
        self.actor = Actor(args, agent_id)  # 需确保Actor输出[mean, log_std]
        self.critic1 = Critic_MADDPG(args)  # 双 Critic 网络减少过估计
        self.critic2 = Critic_MADDPG(args)
        # 目标网络
        self.actor_target = copy.deepcopy(self.actor)
        self.critic1_target = copy.deepcopy(self.critic1)
        self.critic2_target = copy.deepcopy(self.critic2)

        # 优化器
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=self.lr_a)
        self.critic1_optimizer = torch.optim.Adam(self.critic1.parameters(), lr=self.lr_c)
        self.critic2_optimizer = torch.optim.Adam(self.critic2.parameters(), lr=self.lr_c)

    def _reparameterize(self, mean, log_std):
        """重参数化技巧：从高斯分布采样并保留梯度"""
        std = torch.exp(log_std)
        noise = torch.randn_like(std)  # 标准高斯噪声
        x_t = mean + std * noise  # 重参数化采样
        action = torch.tanh(x_t)  # 映射到[-1,1]
        # 计算熵（高斯分布熵 + tanh雅可比修正）
        log_prob = torch.distributions.Normal(mean, std).log_prob(x_t)
        log_prob -= torch.log(1 - action.pow(2) + 1e-6)  # 修正项
        entropy = -log_prob.sum(dim=-1, keepdim=True)
        return action * self.max_action, entropy  # 缩放到[0, max_action]

    def choose_action(self, obs, noise_std=None):
        """选择动作（推理时用均值，训练时带随机性）"""
        obs = torch.unsqueeze(torch.tensor(obs, dtype=torch.float), 0)
        with torch.no_grad():
            mean, log_std = self.actor(obs)  # Actor输出均值和对数标准差
            action, _ = self._reparameterize(mean, log_std)
        return action.numpy().flatten()

    def train(self, replay_buffer, agent_n):
        # 从回放池采样
        batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n = replay_buffer.sample()
        agent_id = self.agent_id
        batch_size = batch_obs_n[0].shape[0]

        # 计算目标Q值
        with torch.no_grad():
            # 所有智能体的下一动作（带熵）
            batch_a_next_n = []
            batch_entropy_next_n = []
            for agent, batch_obs_next in zip(agent_n, batch_obs_next_n):
                mean, log_std = agent.actor_target(batch_obs_next)
                a_next, entropy_next = agent._reparameterize(mean, log_std)
                batch_a_next_n.append(a_next)
                batch_entropy_next_n.append(entropy_next)

            # 双目标 Critic 取最小值（减少过估计）
            q1_next = self.critic1_target(batch_obs_next_n, batch_a_next_n)
            q2_next = self.critic2_target(batch_obs_next_n, batch_a_next_n)
            q_next = torch.min(q1_next, q2_next)

            # 目标Q = 奖励 + 伽马 * (1-终止) * (Q_next + alpha*熵)
            target_Q = batch_r_n[agent_id] + self.gamma * (1 - batch_done_n[agent_id]) * \
                       (q_next + self.alpha * batch_entropy_next_n[agent_id])

        # 更新Critic 1
        current_Q1 = self.critic1(batch_obs_n, batch_a_n)
        critic1_loss = F.mse_loss(current_Q1, target_Q)
        self.critic1_optimizer.zero_grad()
        critic1_loss.backward(retain_graph=True)
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.critic1.parameters(), 10.0)
        self.critic1_optimizer.step()

        # 更新Critic 2
        current_Q2 = self.critic2(batch_obs_n, batch_a_n)
        critic2_loss = F.mse_loss(current_Q2, target_Q)
        self.critic2_optimizer.zero_grad()
        critic2_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.critic2.parameters(), 10.0)
        self.critic2_optimizer.step()

        # 冻结Critic，更新Actor（策略梯度 + 熵最大化）
        mean, log_std = self.actor(batch_obs_n[agent_id])
        a_current, entropy_current = self._reparameterize(mean, log_std)

        # 替换当前智能体的动作为新采样动作
        batch_a_n[agent_id] = a_current.detach()  # 避免Critic梯度影响

        # 计算当前Q值（用最新Critic）
        q1_current = self.critic1(batch_obs_n, batch_a_n)
        q2_current = self.critic2(batch_obs_n, batch_a_n)
        q_current = torch.min(q1_current, q2_current)

        # Actor损失：-（Q值 + alpha*熵）（最大化Q和熵）
        actor_loss = -(q_current + self.alpha * entropy_current).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 10.0)
        self.actor_optimizer.step()

        # 软更新目标网络
        for param, target_param in zip(self.critic1.parameters(), self.critic1_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for param, target_param in zip(self.critic2.parameters(), self.critic2_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def save_model(self, env_name, algorithm, number, total_steps, agent_id):
        torch.save(self.actor.state_dict(),
                   f"./model/{env_name}/{algorithm}_actor_number_{number}_step_{int(total_steps / 1000)}k_agent_{agent_id}.pth")