
import torch
import numpy as np
from collections import deque

class ReplayBuffer(object):
    def __init__(self, args):
        self.buffer_size = args.buffer_size
        self.batch_size = args.batch_size
        self.buffer = deque(maxlen=self.buffer_size)  # 单智能体用队列存储

    def store_transition(self, obs, a, r, obs_next, done):
        """存储单智能体的经验"""
        self.buffer.append((obs, a, r, obs_next, done))

    def sample(self):
        """采样单智能体的批量经验"""
        indices = np.random.choice(len(self.buffer), size=self.batch_size, replace=False)
        batch_obs, batch_a, batch_r, batch_obs_next, batch_done = [], [], [], [], []
        for idx in indices:
            obs, a, r, obs_next, done = self.buffer[idx]
            batch_obs.append(obs)
            batch_a.append(a)
            batch_r.append(r)
            batch_obs_next.append(obs_next)
            batch_done.append(done)
        # 转换为tensor
        return (torch.tensor(np.array(batch_obs), dtype=torch.float),
                torch.tensor(np.array(batch_a), dtype=torch.float),
                torch.tensor(np.array(batch_r), dtype=torch.float).unsqueeze(1),
                torch.tensor(np.array(batch_obs_next), dtype=torch.float),
                torch.tensor(np.array(batch_done), dtype=torch.float).unsqueeze(1))

    def __len__(self):
        return len(self.buffer)