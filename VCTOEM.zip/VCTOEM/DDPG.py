import torch
import torch.nn.functional as F
import numpy as np
import copy
from networks_DDPG import Actor, Critic


class DDPG(object):
    def __init__(self, args):
        self.max_action = args.max_action
        self.action_dim = args.action_dim
        self.obs_dim = args.obs_dim

        # 学习率
        self.lr_a = args.lr_a
        self.lr_c = args.lr_c

        # 折扣因子和软更新系数
        self.gamma = args.gamma
        self.tau = args.tau
        self.use_grad_clip = args.use_grad_clip

        # 初始化Actor和Critic网络
        self.actor = Actor(args)
        self.critic = Critic(args)
        self.actor_target = copy.deepcopy(self.actor)
        self.critic_target = copy.deepcopy(self.critic)

        # 优化器
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=self.lr_a)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=self.lr_c)

    def choose_action(self, obs, noise_std):
        """选择动作（带探索噪声）"""
        # 单智能体仅需自身观测
        obs = torch.unsqueeze(torch.tensor(obs, dtype=torch.float), 0)  # 增加batch维度
        a = self.actor(obs).data.numpy().flatten()  # 生成确定性动作
        # 添加高斯噪声进行探索
        a = (a + np.random.normal(0, noise_std, size=self.action_dim)).clip(0, self.max_action)
        return a

    def train(self, replay_buffer):
        """训练函数（单智能体版本）"""
        # 从经验回放中采样
        batch_obs, batch_a, batch_r, batch_obs_next, batch_done = replay_buffer.sample()

        # 计算目标Q值
        with torch.no_grad():
            batch_a_next = self.actor_target(batch_obs_next)
            Q_next = self.critic_target(batch_obs_next, batch_a_next)
            target_Q = batch_r + self.gamma * (1 - batch_done) * Q_next


        current_Q = self.critic(batch_obs, batch_a)
        critic_loss = F.mse_loss(target_Q, current_Q)

        # 优化Critic
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 10.0)
        self.critic_optimizer.step()

        # 计算Actor损失（最大化Q值）
        # 仅使用当前智能体的观测生成动作
        a_current = self.actor(batch_obs)
        actor_loss = -self.critic(batch_obs, a_current).mean()

        # 优化Actor
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 10.0)
        self.actor_optimizer.step()

        # 软更新目标网络
        self._soft_update(self.critic, self.critic_target)
        self._soft_update(self.actor, self.actor_target)

        return critic_loss.item(), actor_loss.item()  # 返回损失值用于监控

    def _soft_update(self, local_model, target_model):
        """软更新目标网络参数"""
        for param, target_param in zip(local_model.parameters(), target_model.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def save_model(self, env_name, algorithm, number, total_steps):
        """保存模型（单智能体无需agent_id）"""
        torch.save(self.actor.state_dict(),
                   f"./model/{env_name}/{algorithm}_actor_number_{number}_step_{int(total_steps / 1000)}.pth")
        torch.save(self.critic.state_dict(),
                   f"./model/{env_name}/{algorithm}_critic_number_{number}_step_{int(total_steps / 1000)}.pth")