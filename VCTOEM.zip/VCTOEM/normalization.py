class normalization:
    @classmethod
    # def element_norm(cls,delay_list = None,):
    #     if delay_list is None:
    #         delay_list = []
    #     new_d = []
    #     for i in range (len(delay_list)):
    #             new_d.append(delay_list[i]*6e4)
    #     return new_d
    # def element_norm1(cls,energy_list = None,):
    #     if energy_list is None:
    #         energy_list = []
    #     new_d = []
    #     for i in range (len(energy_list)):
    #             new_d.append(energy_list[i]*6e4)
    #     return new_d

    def element_norm(cls, data_list=None, data_type="delay"):
        if data_list is None:
            data_list = []
        new_data = []
        # 根据数据类型选择缩放系数（如果后续需要不同系数，可在此处修改）
        scale_factor = 6e4  # 目前时延和能耗使用相同系数，若需区分可改为条件判断
        # 遍历列表并应用缩放
        for item in data_list:
            new_data.append(item * scale_factor)
        return new_data



