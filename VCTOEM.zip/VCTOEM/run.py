import math

import torch
import numpy as np
from matplotlib import pyplot as plt
from torch.utils.tensorboard import SummaryWriter
import torch.nn.functional as F
import argparse

import normalization
from normalization import *
from replay_buffer import ReplayBuffer

import copy
import os, shutil
from MADDPG import MADDPG
# from changjing_cheliangshuliang import Roadenvironment
from changjing import Roadenvironment

from cluster_3 import cluster
MAX_EPISODES = 3000
MEMORY_CAPACITY = 3000  ###存储容量

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
def mean(numbers):
 return np.mean(numbers)


class Runner:
 def __init__(self, args, number, seed):
  self.args = args
  self.number = number
  self.seed = seed
  self.env = Roadenvironment()
  self.args.N = self.env.task_vehicle
  self.args.obs_dim_n = [427,427,427,427,427]
  self.args.action_dim_n = [6,6,6,6,6]



  if self.args.algorithm == "MADDPG":
   print("Algorithm: MADDPG")
   self.agent_n = [MADDPG(args, agent_id) for agent_id in range(args.N)]

  else:
   print("Wrong!!!")
  self.replay_buffer = ReplayBuffer(self.args)
  self.evaluate_rewards = []          # Record the rewards during the evaluating
  # Create a tensorboard
  # self.writer = SummaryWriter(log_dir='runs/{}/{}_number_{}_seed_{}'.format(self.args.algorithm, self.args.algorithm, self.number, self.seed))
  self.total_steps = 0
  self.noise_std = self.args.noise_std_init  # Initialize noise_std

 def run(self):

  v_c = self.env.get_cluster_head(self.env.t_list)    #获取可用车辆簇的信息
  offloading_point = np.zeros([self.args.N, 7])
  for i in range (0,self.args.N):
    offloading_point[i][0] = self.env.judge_uav(i)
    offloading_point[i][1] = self.env.judge_rsu(i)
    offloading_point[i][2:7] = [x for x in range(5)]
  while self.total_steps < MAX_EPISODES:
   self.env.reset()

   self.env.optimize_uav_trajectory() #无人机轨迹优化


   latency0, energy0, reward0, ex_reward0 = [], [], [], []
   latency1, energy1, reward1, ex_reward1 = [], [], [], []
   latency2, energy2, reward2, ex_reward2 = [], [], [], []
   latency3, energy3, reward3, ex_reward3 = [], [], [], []
   latency4, energy4, reward4, ex_reward4 = [], [], [], []
   agent0_state = self.env.get_agaent0_state()
   agent1_state = self.env.get_agaent1_state()
   agent2_state = self.env.get_agaent2_state()
   agent3_state = self.env.get_agaent3_state()
   agent4_state = self.env.get_agaent4_state()
   obs_n = [agent0_state,agent1_state,agent2_state,agent3_state,agent4_state]
   a_n = [agent.choose_action(obs, noise_std=self.noise_std) for agent, obs in zip(self.agent_n, obs_n)]

   # 更新所有实体位置
   self.env.renew_position()
   # 二次优化轨迹
   self.env.optimize_uav_trajectory()

   uav = [[] , []]
   Rsu = [[] , [] , [] , [] , [] , [] , [] , []]
   Cluster = [[], [] , [] , [] , []]
   # 恢复到原始的动作处理逻辑，但改进资源分配方式
   for i in range(0, len(a_n)):
       a_c = a_n[i]

       # 处理前4个动作
       for j in range(0, len(a_c) - 2):
           t_in = []
           all_t_in = []
           task_boxer = []

           if i == 0:
               t_in = self.env.v0[j + 1]
               all_t_in = self.env.v0_a[j]
           elif i == 1:
               t_in = self.env.v1[j + 1]
               all_t_in = self.env.v1_a[j]
           elif i == 2:
               t_in = self.env.v2[j + 1]
               all_t_in = self.env.v2_a[j]
           elif i == 3:
               t_in = self.env.v3[j + 1]
               all_t_in = self.env.v3_a[j]
           elif i == 4:
               t_in = self.env.v4[j + 1]
               all_t_in = self.env.v4_a[j]

           task_boxer = [t_in, all_t_in, i]

           # 使用原始动作区间划分
           if a_c[j] >= 0 and a_c[j] <= 7 / 16:  # 任务卸载到uav
               uav[int(offloading_point[i][0])].append(task_boxer)
           elif a_c[j] > 7 / 16 and a_c[j] <= 14 / 16:  # 任务卸载到RSU
               Rsu[int(offloading_point[i][1])].append(task_boxer)
           elif a_c[j] > 14 / 16 and a_c[j] <= 1:  # 任务卸载到簇
               Cluster[i].append(task_boxer)
#*************************uav资源分配**********************************************
   for i in range(2):
       uav_resource = 0
       b_boxer = uav[i]

       # 首先计算每个任务的基础需求
       base_demands = []
       for j in range(len(b_boxer)):
           p = b_boxer[j]
           w = p[1]
           base_demand = math.ceil(w[1] * 1e-5)
           base_demands.append(base_demand)
           uav_resource += base_demand

       # 如果UAV有分配到任务，使用智能体的动作作为权重
       if len(b_boxer) > 0:
           agent_id = b_boxer[0][2]  # 从第一个任务获取智能体ID
           if agent_id < len(a_n):
               agent_actions = a_n[agent_id]
               weight_start_idx = min(4, len(agent_actions))
               weights = []

               # 为每个任务分配权重
               for j in range(len(b_boxer)):
                   if j < (len(agent_actions) - weight_start_idx):
                       weight = agent_actions[weight_start_idx + j]
                   else:
                       weight = 1.0  # 默认权重
                   weights.append(max(0.1, weight))  # 确保权重为正数

               # 根据权重分配资源
               total_weight = sum(weights)
               for j in range(len(b_boxer)):
                   p = b_boxer[j]
                   w = p[1]

                   if total_weight > 0:
                       weight_ratio = weights[j] / total_weight
                       uav_a = weight_ratio * self.env.uav_cc
                   else:
                       uav_a = (base_demands[j] / uav_resource) * self.env.uav_cc

                   uav[i][j] = p + [uav_a]
           else:
               # 如果没有动作信息，使用均匀分配
               for j in range(len(b_boxer)):
                   p = b_boxer[j]
                   w = p[1]
                   uav_a = (base_demands[j] / uav_resource) * self.env.uav_cc
                   uav[i][j] = p + [uav_a]
       else:
           # 如果没有任务，不需要分配
           pass
#***********************************RSU资源分配****************************************
   for i in range(8):
       rsu_resource = 0
       r_boxer = Rsu[i]

       # 简单计算：基于任务大小分配资源
       for j in range(len(r_boxer)):
           p = r_boxer[j]
           w = p[1]
           rsu_resource += math.ceil(w[1] * 1e-5)

       for j in range(len(r_boxer)):
           rc_a = 0
           p = r_boxer[j]
           w = p[1]

           if rsu_resource > 0:
               rc_a = (math.ceil(w[1] * 1e-5) / rsu_resource) * self.env.Rsu_cc
           else:
               rc_a = 0

           Rsu[i][j] = p + [rc_a]
#********************************************获取时延,能耗，效益****************************************
   for i in range(self.env.A):
       for j in range(len(uav[i])):
           ltc = []  # 存储返回的时延列表
           ener = []  # 存储返回的能耗列表
           ut = []  # 存储返回的效益
           temp = uav[i][j]

           # 计算时延列表和能耗列表（所有类型任务通用）
           ltc = self.env.uav_latency(temp[3], temp[0], temp[1])  # 时延列表
           ener = self.env.uav_energy(temp[3], temp[0], temp[1])  # 新增：获取能耗列表

           #  根据任务类型处理（补充energy_list参数传递）
           if temp[2] == 0:
               latency0.append(ltc[-1])  # 总时延
               energy0.append(ener[-1])  # 总能耗
               # 调用Bs_utility时传入energy_list
               ut = self.env.uav_utility(0, i, ltc, temp[1], ener)
               reward0.append(ut[i][2])
               ex_reward0.append(ut[i][1])#utility
           elif temp[2] == 1:
               latency1.append(ltc[-1])
               energy1.append(ener[-1])  # 总能耗
               ut = self.env.uav_utility(1, i, ltc, temp[1], ener)
               reward1.append(ut[i][2])
               ex_reward1.append(ut[i][1])
           elif temp[2] == 2:
               latency2.append(ltc[-1])
               energy2.append(ener[-1])  # 总能耗
               ut = self.env.uav_utility(2, i, ltc, temp[1], ener)
               reward2.append(ut[i][2])
               ex_reward2.append(ut[i][1])
           elif temp[2] == 3:
               latency3.append(ltc[-1])
               energy3.append(ener[-1])  # 总能耗
               ut = self.env.uav_utility(3, i, ltc, temp[1], ener)
               reward3.append(ut[i][2] )
               ex_reward3.append(ut[i][1])
           elif temp[2] == 4:
               latency4.append(ltc[-1])
               energy4.append(ener[-1])  # 总能耗
               ut = self.env.uav_utility(4, i, ltc, temp[1], ener)
               reward4.append(ut[i][2])
               ex_reward4.append(ut[i][1])

   for i in range(self.env.B):
       for j in range(len(Rsu[i])):
           ltc = []  # 放返回时延
           ener = []  # 存储返回的能耗列表
           ut = []  # 放返回效益
           temp = Rsu[i][j]
           ltc = self.env.Rsu_latency(temp[3], temp[0], temp[1])
           ener = self.env.Rsu_energy(temp[3], temp[0], temp[1])  # 获取能耗列表
           if temp[2] == 0:
              latency0.append(ltc[-1])  # 只看总时延
              energy0.append(ener[-1])  # 只看总能耗
              ut = self.env.Rsu_utility(0, i, ltc, temp[1], ener)
              reward0.append(ut[i][2])
              ex_reward0.append(ut[i][1])
           elif temp[2] == 1:
              latency1.append(ltc[-1])  # 只看总时延
              energy1.append(ener[-1])
              ut = self.env.Rsu_utility(1, i, ltc, temp[1], ener)
              reward1.append(ut[i][2])
              ex_reward1.append(ut[i][1])
           elif temp[2] == 2:
              latency2.append(ltc[-1])  # 只看总时延
              energy2.append(ener[-1])
              ut = self.env.Rsu_utility(2, i, ltc, temp[1], ener)
              reward2.append(ut[i][2])
              ex_reward2.append(ut[i][1])
           elif temp[2] == 3:
              latency3.append(ltc[-1])  # 只看总时延
              energy3.append(ener[-1])
              ut = self.env.Rsu_utility(3, i, ltc, temp[1], ener)
              reward3.append(ut[i][2])
              ex_reward3.append(ut[i][1])
           elif temp[2] == 4:
              latency4.append(ltc[-1])  # 只看总时延
              energy4.append(ener[-1])
              ut = self.env.Rsu_utility(4, i, ltc, temp[1], ener)
              reward4.append(ut[i][2])
              ex_reward4.append(ut[i][1])
#***************************簇内车辆选择***************************************
   for i in range(self.env.task_vehicle):
    act = a_n[i]
    c_cl = v_c[i]   #获取第i辆车所能卸载到的簇
    sub_task_infomation = []
    a_t_i = []      #存取任务总信息
    ex_price = self.env.ex_price(act[len(act)-2]) #取最后 代表单价
    offload_cluster = act[-2]
    num = len(Cluster[i])    #卸载到簇任务数
    for j in range (num):
     temp = Cluster[i][j]
     sub_task = temp[0]      #所有子任务信息
     a_t = temp[1]           #任务总信息
     sub_task_infomation.append(sub_task)
     a_t_i.append(a_t)
    ac_option = cluster.cluster_ac_choose(num,offload_cluster,sub_task_infomation,c_cl)
    result_parameter = self.env.opt_ve_offlod(ex_price,i,ac_option,a_t_i)
    if i == 0:
     latency0 += result_parameter[0]
     reward0 += result_parameter[2]
     ex_reward0 += result_parameter[1]
     energy0 += result_parameter[3]
    elif i == 1:
     latency1 += result_parameter[0]
     reward1 += result_parameter[2]
     ex_reward1 += result_parameter[1]
     energy1 += result_parameter[3]
    elif i == 2:
     latency2 += result_parameter[0]
     reward2 += result_parameter[2]
     ex_reward2 += result_parameter[1]
     energy2 += result_parameter[3]
    elif i == 3:
     latency3 += result_parameter[0]
     reward3 += result_parameter[2]
     ex_reward3 += result_parameter[1]
     energy3 += result_parameter[3]
    elif i == 4:
     latency4 += result_parameter[0]
     reward4 += result_parameter[2]
     ex_reward4 += result_parameter[1]
     energy4 += result_parameter[3]
   done_n = [False, False, False, False, False]
   r_n = []
   r_n.append(mean(reward0))
   r_n.append(mean(reward1))
   r_n.append(mean(reward2))
   r_n.append(mean(reward3))
   r_n.append(mean(reward4))

   # a_r_e = [sum(reward0)+sum(reward1)+sum(reward2)+sum(reward3)+sum(reward4)]
   a_r_e = (mean(reward0) + mean(reward1) + mean(reward2) + mean(reward3) + mean(reward4))/5  #平均奖励
   are.append(a_r_e)
   ave.append((mean(ex_reward0) + mean(ex_reward1) + mean(ex_reward2) + mean(ex_reward3) + mean(ex_reward4))/5)  #平均效用
   agent0_state = self.env.get_agaent0_state()
   agent1_state = self.env.get_agaent1_state()
   agent2_state = self.env.get_agaent2_state()
   agent3_state = self.env.get_agaent3_state()
   agent4_state = self.env.get_agaent4_state()
   obs_next_n = [agent0_state,agent1_state,agent2_state,agent3_state,agent4_state]
   self.replay_buffer.store_transition(obs_n,a_n,r_n,obs_next_n,done_n)
   obs_n = obs_next_n
   latency0 = normalization.element_norm(latency0,data_type="delay")
   latency1 = normalization.element_norm(latency1,data_type="delay")
   latency2 = normalization.element_norm(latency2,data_type="delay")
   latency3 = normalization.element_norm(latency3,data_type="delay")
   latency4 = normalization.element_norm(latency4,data_type="delay")

   energy0 = normalization.element_norm(energy0,data_type="energy")
   energy1 = normalization.element_norm(energy1,data_type="energy")
   energy2 = normalization.element_norm(energy2,data_type="energy")
   energy3 = normalization.element_norm(energy3,data_type="energy")
   energy4 = normalization.element_norm(energy4,data_type="energy")

   ex0.append(np.mean(ex_reward0))
   ex1.append(np.mean(ex_reward1))
   ex2.append(np.mean(ex_reward2))
   ex3.append(np.mean(ex_reward3))
   ex4.append(np.mean(ex_reward4))
   re0.append(np.mean(reward0))
   re1.append(np.mean(reward1))
   re2.append(np.mean(reward2))
   re3.append(np.mean(reward3))
   re4.append(np.mean(reward4))
   delay0.append(mean(latency0))
   delay1.append(mean(latency1))
   delay2.append(mean(latency2))
   delay3.append(mean(latency3))
   delay4.append(mean(latency4))

   en0.append(mean(energy0))
   en1.append(mean(energy1))
   en2.append(mean(energy2))
   en3.append(mean(energy3))
   en4.append(mean(energy4))

   adl.append((mean(latency0)+mean(latency1)+mean(latency2)+mean(latency3)+mean(latency4))/5)  #平均时延

   ade.append((mean(energy0) + mean(energy1) + mean(energy2) + mean(energy3) + mean(energy4)) / 5)  #平均能耗
   print('\nStep-%d' % self.total_steps)

   print('agent_0_reward: ', reward0)
   print('agent_1_reward: ', reward1)
   print('agent_2_reward: ', reward2)

   print('agent_0_latency: ', latency0)
   print('agent_1_latency: ', latency1)
   print('agent_2_latency: ', latency2)
   print('agent_3_latency: ', latency3)
   print('agent_4_latency: ', latency4)

   print('agent_0_energy: ', energy0)
   print('agent_1_energy: ', energy1)
   print('agent_2_energy: ', energy2)
   print('agent_3_energy: ', energy3)
   print('agent_4_energy: ', energy4)

   if (self.total_steps + 1) % 100 == 0:

    np.save('{}/{}.npy'.format(writepath, "utility_reward"), np.array(are))
   self.total_steps+=1
   if self.args.use_noise_decay:
    self.noise_std = self.noise_std - self.args.noise_std_decay if self.noise_std - self.args.noise_std_decay > self.args.noise_std_min else self.args.noise_std_min
   if self.replay_buffer.current_size > self.args.batch_size:
    # Train each agent individually
    for agent_id in range(self.args.N):
     self.agent_n[agent_id].train(self.replay_buffer, self.agent_n)

if __name__ == '__main__':
 writepath = 'real'
 if os.path.exists(writepath): shutil.rmtree(writepath)
 if not os.path.exists(writepath): os.mkdir(writepath)
 writer = SummaryWriter(log_dir=writepath)
 parser = parser = argparse.ArgumentParser("Hyperparameters Setting for MADDPG in MPE environment")
 parser.add_argument("--max_train_steps", type=int, default=int(6000), help=" Maximum number of training steps") #最大训练步数（全局总步数）
 # parser.add_argument("--episode_limit", type=int, default=25, help="Maximum number of steps per episode")
 # parser.add_argument("--evaluate_freq", type=float, default=5000, help="Evaluate the policy every 'evaluate_freq' steps")
 # parser.add_argument("--evaluate_times", type=float, default=3, help="Evaluate times")
 parser.add_argument("--max_action", type=float, default=1, help="Max action") #智能体动作的最大值（动作空间上限）

 parser.add_argument("--algorithm", type=str, default="MADDPG", help="MADDPG or MATD3")
 parser.add_argument("--buffer_size", type=int, default=int(10000), help="The capacity of the replay buffer") #经验回放缓冲区的容量10000
 parser.add_argument("--batch_size", type=int, default=32, help="Batch size") #经验批次大小256
 parser.add_argument("--hidden_dim", type=int, default=256,
                     help="The number of neurons in hidden layers of the neural network") #神经网络第一层隐藏层的神经元数量256
 parser.add_argument("--hidden_dim1", type=int, default=128,
                     help="The number of neurons in hidden layers of the neural network") #第二层
 parser.add_argument("--noise_std_init", type=float, default=0.1, help="The std of Gaussian noise for exploration") #探索阶段高斯噪声的初始标准差0.1
 parser.add_argument("--noise_std_min", type=float, default=0.05, help="The std of Gaussian noise for exploration") #噪声标准差的最小值0.05
 parser.add_argument("--noise_decay_steps", type=float, default=1000,
                     help="How many steps before the noise_std decays to the minimum") #噪声从初始值衰减到最小值所需的训练步数1000
 parser.add_argument("--use_noise_decay", type=bool, default=True, help="Whether to decay the noise_std") #是否启用噪声衰减机制
 parser.add_argument("--lr_a", type=float, default=0.0001, help="Learning rate of actor") #0.001 0.00001  Actor（策略网络）的学习率
 parser.add_argument("--lr_c", type=float, default=0.003, help="Learning rate of critic") #0.0015 0.0003  Critic（价值网络）的学习率
 parser.add_argument("--gamma", type=float, default=0.95, help="Discount factor") #折扣因子
 parser.add_argument("--tau", type=float, default=0.01, help="Softly update the target network") #目标网络软更新系数0.2 0.01
 parser.add_argument("--use_orthogonal_init", type=bool, default=False, help="Orthogonal initialization") #是否使用正交初始化方式初始化神经网络参数
 parser.add_argument("--use_grad_clip", type=bool, default=False, help="Gradient clip") #是否启用梯度裁剪

 args = parser.parse_args()
 args.noise_std_decay = (args.noise_std_init - args.noise_std_min) / args.noise_decay_steps
 runner = Runner(args,number=1,seed=512)
 ex0, re0, delay0, en0 = [], [], [], []
 ex1, re1, delay1, en1 = [], [], [], []
 ex2, re2, delay2, en2 = [], [], [], []
 ex3, re3, delay3, en3 = [], [], [], []
 ex4, re4, delay4, en4 = [], [], [], []
 ave = []
 adl = []
 ade = []
 are = []
 runner.run()

# 训练结束后读取保存的数据
def plot_results(writepath):
    # 读取数据
    ave_reward = np.load(f"{writepath}/utility_reward.npy")
    #  绘制全局平均奖励曲线 - 单独保存
    plt.figure(figsize=(10, 6))
    plt.plot(ave_reward, label='Average Extrinsic Reward', color='green')
    plt.xlabel('Episodes')
    plt.ylabel('Average Reward')
    plt.title('Global Average Extrinsic Reward')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{writepath}/global_average_reward.png")
    plt.show()

# 调用绘图函数
plot_results(writepath)
