
import random
import numpy as np
np.random.seed(1024)


N = 200
M = 4
class information: #随机生成200空闲辆车坐标和10辆任务车坐标
    @classmethod
    def ve_information(self):
     V_ele = np.ones([N,M])
     for i in range(N):
        V_ele[i][0]=np.random.uniform(0, 1000)#横坐标
        V_ele[i][1]=np.random.uniform(0, 21) #纵坐标
        V_ele[i][2]=np.random.uniform(30,45) #通信半径
        # V_ele[i][4]=np.random.randint(0.7e9,0.9e9) #计算速度 0.7-0.9Gcycle/s
        # V_ele[i][5]=np.random.randint(1e9,2e9) #可用资源大小 1-2G 几乎不会耗尽
     for i in range(N):   #生成速度
        if(V_ele[i][1]<3.5 and V_ele[i][1]>0):
            m = np.random.uniform(16.66,33.33)
            V_ele[i][3] = m
        elif(V_ele[i][1]<7 and V_ele[i][1]>3.5):
            m = np.random.uniform(25,33.33)
            V_ele[i][3] = m
        elif (V_ele[i][1] < 10.5 and V_ele[i][1] > 7):
            m = np.random.uniform(30.55, 33.33)
            V_ele[i][3] = m
        elif (V_ele[i][1] < 14 and V_ele[i][1] > 10.5):
            m = np.random.uniform(-33.33, -16.66)
            V_ele[i][3] = m
        elif (V_ele[i][1] < 17.5 and V_ele[i][1] > 14):
            m = np.random.uniform(-33.33, -25)
            V_ele[i][3] = m
        elif (V_ele[i][1] < 21 and V_ele[i][1] > 17.5):
            m = np.random.uniform(-33.33, -30.55)
            V_ele[i][3] = m
     return V_ele

     # for i in range(N):  # 生成速度
     #     if (V_ele[i][1] < 3.5 and V_ele[i][1] > 0):
     #         m = np.random.uniform(45, 60)
     #         V_ele[i][3] = m
     #     elif (V_ele[i][1] < 7 and V_ele[i][1] > 3.5):
     #         m = np.random.uniform(50, 60)
     #         V_ele[i][3] = m
     #     elif (V_ele[i][1] < 10.5 and V_ele[i][1] > 7):
     #        m = np.random.uniform(55, 60)
     #        V_ele[i][3] = m
     #     elif (V_ele[i][1] < 14 and V_ele[i][1] > 10.5):
     #        m = np.random.uniform(-60, -45)
     #        V_ele[i][3] = m
     #     elif (V_ele[i][1] < 17.5 and V_ele[i][1] > 14):
     #        m = np.random.uniform(-60, -50)
     #        V_ele[i][3] = m
     #     elif (V_ele[i][1] < 21 and V_ele[i][1] > 17.5):
     #        m = np.random.uniform(-60, -55)
     #        V_ele[i][3] = m
     # return V_ele

    def ve_cm(self):
        oo = np.zeros(N)
        for i in range (N):
            oo [i] = np.random.randint(0.79e9,1.2e9)#0.7-0.9  e9
            oo[i] = np.random.randint(0.9e9, 1.1e9)  # 0.7-0.9
        return oo
    def ve_t_information(self):
     V_task = np.ones([5,4])
     V_task[0][0] = np.random.uniform(50,150) #确保均分 因为地图太大任务车辆太少很容易挤到一起
     V_task[1][0] = np.random.uniform(250,350)
     V_task[2][0] = np.random.uniform(450,550)
     V_task[3][0] = np.random.uniform(650,750)
     V_task[4][0] = np.random.uniform(850,1000)

     for i in range(5):
        b = np.random.uniform(0, 24) #纵坐标
        V_task[i][1]=b
        V_task[i][2]=np.random.randint(0.7e9,0.8e9)       #计算速度 0.7-0.8Gcycles/s
     for i in range(5):   #生成速度
        if(V_task[i][1]<3.5 and V_task[i][1]>0):
            m = np.random.uniform(16.66,33.33)
            V_task[i][3] = m
        elif(V_task[i][1]<7 and V_task[i][1]>3.5):
            m = np.random.uniform(25,33.33)
            V_task[i][3] = m
        elif (V_task[i][1] < 10.5 and V_task[i][1] > 7):
            m = np.random.uniform(30.55, 33.33)
            V_task[i][3] = m
        elif (V_task[i][1] < 14 and V_task[i][1] > 10.5):
            m = np.random.uniform(-33.33, -16.66)
            V_task[i][3] = m
        elif (V_task[i][1] < 17.5 and V_task[i][1] > 14):
            m = np.random.uniform(-33.33, -25)
            V_task[i][3] = m
        elif (V_task[i][1] < 21 and V_task[i][1] > 17.5):
            m = np.random.uniform(-33.33, -30.55)
            V_task[i][3] = m
     return V_task

    # def ve_t_information(self):
    #     V_task = np.ones([3, 4])  # 改为3辆任务车辆
    #     # 调整x坐标区间，保持均匀分布
    #     V_task[0][0] = np.random.uniform(50, 350)  # 第一辆车x坐标范围
    #     V_task[1][0] = np.random.uniform(450, 750)  # 第二辆车x坐标范围
    #     V_task[2][0] = np.random.uniform(850, 1000)  # 第三辆车x坐标范围
    #
    #     # 生成y坐标和计算速度
    #     for i in range(3):
    #         b = np.random.uniform(0, 24)  # 纵坐标范围不变
    #         V_task[i][1] = b
    #         V_task[i][2] = np.random.randint(0.7e9, 0.8e9)  # 计算速度范围不变
    #
    #     # 调整速度划分区间（按3辆车辆对应调整y坐标区间划分）
    #     for i in range(3):
    #         if 0 < V_task[i][1] < 8:  # 第一区间：0-8
    #             m = np.random.uniform(16.66, 33.33)
    #             V_task[i][3] = m
    #         elif 8 < V_task[i][1] < 16:  # 第二区间：8-16
    #             m = np.random.uniform(-33.33, -16.66)
    #             V_task[i][3] = m
    #         elif 16 < V_task[i][1] < 24:  # 第三区间：16-24
    #             m = np.random.uniform(20, 30)  # 中间过渡区间速度
    #             V_task[i][3] = m
    #     return V_task



