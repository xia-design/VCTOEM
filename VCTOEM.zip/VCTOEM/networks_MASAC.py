import torch
import torch.nn as nn
import torch.nn.functional as F
import math


def orthogonal_init(layer, gain=1.0):
    """正交初始化，保持与原逻辑一致"""
    for name, param in layer.named_parameters():
        if 'bias' in name:
            nn.init.constant_(param, 0)
        elif 'weight' in name:
            nn.init.orthogonal_(param, gain=gain)


class Actor(nn.Module):


    def __init__(self, args, agent_id):
        super(Actor, self).__init__()
        self.max_action = args.max_action
        self.action_dim = args.action_dim_n[agent_id]  # 当前智能体的动作维度

        # 网络结构（与原MADDPG一致，仅输出层调整）
        self.fc1 = nn.Linear(args.obs_dim_n[agent_id], args.hidden_dim)
        self.fc2 = nn.Linear(args.hidden_dim, args.hidden_dim1)
        self.fc3 = nn.Linear(args.hidden_dim1, 2 * self.action_dim)  # 输出mean和log_std（各占action_dim）

        if args.use_orthogonal_init:
            print("------use_orthogonal_init------")
            orthogonal_init(self.fc1)
            orthogonal_init(self.fc2)
            orthogonal_init(self.fc3)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        out = self.fc3(x)

        # 分割为均值和对数标准差
        mean = out[:, :self.action_dim]
        log_std = out[:, self.action_dim:]

        # 限制log_std范围（避免标准差过大或过小）
        log_std = torch.clamp(log_std, min=-20, max=2)
        return mean, log_std  # 返回高斯分布参数


class Critic_MADDPG(nn.Module):

    def __init__(self, args):
        super(Critic_MADDPG, self).__init__()
        # 输入维度：所有智能体的观测维度之和 + 所有智能体的动作维度之和
        input_dim = sum(args.obs_dim_n) + sum(args.action_dim_n)

        # 网络结构（与原MADDPG一致）
        self.fc1 = nn.Linear(input_dim, args.hidden_dim)
        self.fc2 = nn.Linear(args.hidden_dim, args.hidden_dim1)
        self.fc3 = nn.Linear(args.hidden_dim1, 1)

        if args.use_orthogonal_init:
            print("------use_orthogonal_init------")
            orthogonal_init(self.fc1)
            orthogonal_init(self.fc2)
            orthogonal_init(self.fc3)

    def forward(self, s, a):
        """
        s: 所有智能体的观测列表，每个元素形状[batch_size, obs_dim]
        a: 所有智能体的动作列表，每个元素形状[batch_size, action_dim]
        """
        s_cat = torch.cat(s, dim=1)  # 拼接所有观测
        a_cat = torch.cat(a, dim=1)  # 拼接所有动作
        x = torch.cat([s_cat, a_cat], dim=1)  # 观测+动作拼接

        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        q_value = self.fc3(x)
        return q_value