import numpy as np


class task:
    @classmethod
    def task_generate(self):  # 单任务车辆x生成任务

        # 入口任务：三元组 (数据量, 计算量, 截止时间)
        in_inputdata = np.random.randint(300, 480)  # 输入数据量为300~500 bit
        in_cm_size = np.random.randint(2.5e5, 3e5)  # 计算任务量为250k~300k cycles
        in_deadline = np.random.uniform(6e-2, 9e-2)  # 截止时间60~90ms

        # 出口任务：三元组 (数据量, 计算量, 截止时间)
        out_inputdata = np.random.randint(300, 480)  # 输入数据量为300~500 bit
        out_cm_size = np.random.randint(2e5, 3e5)  # 计算任务量为200k~300k cycles
        out_deadline = np.random.uniform(6e-2, 9e-2)  # 截止时间60~90ms

        # 核心任务：w个依赖性任务，每个有p个子任务
        w = 4  # 4个具有依赖性的任务（对应论文中的w+2个任务中的核心任务）
        n = []  # 存放所有任务信息集合

        # 第一维：入口任务和出口任务
        intask = [in_inputdata, in_cm_size, in_deadline]  # 入口任务三元组
        outtask = [out_inputdata, out_cm_size, out_deadline]  # 出口任务三元组
        k = [intask, outtask]
        n.append(k)

        # 生成w个核心任务，每个包含p个子任务
        for i in range(0, w):
            p = np.random.randint(3, 6)  # 每个核心任务有3~5个子任务
            temp_w_task = []  # 存储当前核心任务的子任务

            for j in range(0, p):
                # 子任务五元组: [子任务大小D_s, 输入数据I_s, 计算量C_s, 输出数据O_s, 截止时间T_s_max]
                D_s = np.random.randint(400, 450)  # 子任务大小
                I_s = 0 if j == 0 else temp_w_task[j - 1][3]  # 输入=前一个子任务的输出
                C_s = np.random.randint(3e5, 4e5)  # 计算量
                O_s = np.random.randint(400, 450)  # 输出数据
                T_s_max = np.random.uniform(6e-2, 9e-2)  # 截止时间

                temp_p_task = [D_s, I_s, C_s, O_s, T_s_max]
                temp_w_task.append(temp_p_task)

            n.append(temp_w_task)
        return n

    @classmethod
    def get_total_task_information(self, t=[]):
        """
  获取任务总信息，保持原有接口不变
  返回：二维列表 [[总数据量, 总计算量, 最小截止时间], ...]
  """
        f = []  # 二维列表

        # 遍历所有核心任务（从索引1开始）
        for i in range(1, len(t)):
            x = t[i]  # 第i个核心任务的所有子任务
            total_input = 0  # 总输入数据量（第一个子任务的输入）
            total_cm_size = 0  # 总计算量
            deadlines = []  # 所有子任务截止时间

            for j in range(0, len(x)):
                y = x[j]  # 子任务五元组
                if j == 0:
                    total_input = y[1]  # 第一个子任务的输入
                total_cm_size += y[2]  # 累加计算量
                deadlines.append(y[4])  # 收集截止时间

            # 总信息：[总输入数据量, 总计算量, 最小截止时间]
            information_boxer = [total_input, total_cm_size, min(deadlines)]
            f.append(information_boxer)

        return f