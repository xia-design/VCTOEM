import torch
import numpy as np


class ReplayBuffer(object):


    def __init__(self, args):
        self.N = args.N  # 智能体数量
        self.buffer_size = args.buffer_size  # 缓冲区最大容量
        self.batch_size = args.batch_size  # 采样批次大小
        self.count = 0  # 当前存储位置指针
        self.current_size = 0  # 当前存储数量

        # 初始化缓冲区（与原结构一致）
        self.buffer_obs_n = []  # 所有智能体的观测：[agent0_obs, agent1_obs, ...]
        self.buffer_a_n = []  # 所有智能体的动作：[agent0_action, agent1_action, ...]
        self.buffer_r_n = []  # 所有智能体的奖励：[agent0_reward, agent1_reward, ...]
        self.buffer_obs_next_n = []  # 所有智能体的下一观测
        self.buffer_done_n = []  # 所有智能体的终止标志

        for agent_id in range(self.N):
            # 每个智能体的观测/动作缓冲区（形状：[buffer_size, 维度]）
            self.buffer_obs_n.append(np.empty((self.buffer_size, args.obs_dim_n[agent_id])))
            self.buffer_a_n.append(np.empty((self.buffer_size, args.action_dim_n[agent_id])))
            self.buffer_r_n.append(np.empty((self.buffer_size, 1)))  # 奖励维度为1
            self.buffer_obs_next_n.append(np.empty((self.buffer_size, args.obs_dim_n[agent_id])))
            self.buffer_done_n.append(np.empty((self.buffer_size, 1)))  # 终止标志为布尔值（0/1）

    def store_transition(self, obs_n, a_n, r_n, obs_next_n, done_n):

        for agent_id in range(self.N):
            self.buffer_obs_n[agent_id][self.count] = obs_n[agent_id]
            self.buffer_a_n[agent_id][self.count] = a_n[agent_id]
            self.buffer_r_n[agent_id][self.count] = r_n[agent_id]
            self.buffer_obs_next_n[agent_id][self.count] = obs_next_n[agent_id]
            self.buffer_done_n[agent_id][self.count] = done_n[agent_id]

        # 更新指针和当前存储量
        self.count = (self.count + 1) % self.buffer_size  # 循环存储
        self.current_size = min(self.current_size + 1, self.buffer_size)

    def sample(self):

        # 随机采样索引（允许重复采样，避免缓冲区未满时的问题）
        index = np.random.choice(self.current_size, size=self.batch_size, replace=True)

        # 构建批次数据（转换为torch.Tensor）
        batch_obs_n, batch_a_n, batch_r_n = [], [], []
        batch_obs_next_n, batch_done_n = [], []

        for agent_id in range(self.N):
            batch_obs_n.append(torch.tensor(self.buffer_obs_n[agent_id][index], dtype=torch.float))
            batch_a_n.append(torch.tensor(self.buffer_a_n[agent_id][index], dtype=torch.float))
            batch_r_n.append(torch.tensor(self.buffer_r_n[agent_id][index], dtype=torch.float))
            batch_obs_next_n.append(torch.tensor(self.buffer_obs_next_n[agent_id][index], dtype=torch.float))
            batch_done_n.append(torch.tensor(self.buffer_done_n[agent_id][index], dtype=torch.float))

        return batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n